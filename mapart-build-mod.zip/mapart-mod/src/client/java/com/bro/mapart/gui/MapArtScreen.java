package com.bro.mapart.gui;

import com.bro.mapart.MapArtClient;
import com.bro.mapart.build.AutoBuilder;
import com.bro.mapart.image.MapArtGrid;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * GUI hien danh sach block/item can chuan bi cho mapart hien tai.
 * Mo/dong bang phim M (dinh nghia trong MapArtKeyBindings).
 *
 * Layout:
 *   - Header: ten anh, kich thuoc, tien do xay
 *   - Danh sach item co scroll: icon + ten + so luong + so stack
 *   - Footer: so loai block + nut Stop/Resume + nut Dong
 */
public class MapArtScreen extends Screen {

    // mau sac
    private static final int BG          = 0xCC0D0D0D;
    private static final int PANEL_BG    = 0xCC1A1A2E;
    private static final int BORDER      = 0xFF16213E;
    private static final int ACCENT      = 0xFF0F3460;
    private static final int TEXT_WHITE  = 0xFFFFFFFF;
    private static final int TEXT_GRAY   = 0xFFAAAAAA;
    private static final int TEXT_GREEN  = 0xFF55FF55;
    private static final int TEXT_YELLOW = 0xFFFFAA00;
    private static final int BAR_BG      = 0xFF333333;
    private static final int BAR_GREEN   = 0xFF00AA44;
    private static final int BAR_YELLOW  = 0xFFFFAA00;
    private static final int BAR_CYAN    = 0xFF55FFFF;

    // kich thuoc panel
    private static final int PANEL_W  = 320;
    private static final int HEADER_H = 52;
    private static final int FOOTER_H = 44;
    private static final int ROW_H    = 22;
    private static final int SCROLL_W = 8;
    private static final int ICON_SZ  = 16;

    // du lieu
    private final List<ItemRow> rows = new ArrayList<>();
    private int totalBlocks;      // so o CO block (tong item can)
    private int builtBlocks;      // so o da xu ly (realtime)
    private int progressTotal;    // tong so o trong thu tu xay (mau so cua thanh tien do)
    private String imageName = "";
    private String sizeLabel = "";

    // scroll
    private int scrollOffset      = 0;
    private int visibleRows       = 0;
    private boolean dragging      = false;
    private double dragStartY     = 0;
    private int dragStartOffset   = 0;

    // vi tri panel (tinh trong init)
    private int panelX, panelY, panelH, listY, listH;

    // nut bam
    private ButtonWidget stopResumeBtn;

    private record ItemRow(Item item, Identifier id, int count, int stacks, boolean inInventory) {}

    public MapArtScreen() {
        super(Text.literal("MapArt – Danh sach block"));
    }

    // ===== INIT =====

    @Override
    protected void init() {
        refresh();

        int rowsToShow = Math.min(Math.max(6, rows.size()), (height - 80 - HEADER_H - FOOTER_H) / ROW_H);
        panelH  = HEADER_H + FOOTER_H + ROW_H * rowsToShow + 12;
        panelH  = Math.min(panelH, height - 40);
        panelX  = (width - PANEL_W) / 2;
        panelY  = (height - panelH) / 2;
        listY   = panelY + HEADER_H + 4;
        listH   = panelH - HEADER_H - FOOTER_H - 8;
        visibleRows = listH / ROW_H;

        int btnY = panelY + panelH - FOOTER_H + 12;

        stopResumeBtn = ButtonWidget.builder(
                Text.literal(builderLabel()),
                btn -> onStopResume()
        ).dimensions(panelX + 8, btnY, 90, 20).build();
        addDrawableChild(stopResumeBtn);

        addDrawableChild(ButtonWidget.builder(
                Text.literal("Dong  [M]"),
                btn -> close()
        ).dimensions(panelX + PANEL_W - 78, btnY, 70, 20).build());
    }

    private void refresh() {
        rows.clear();
        AutoBuilder builder = MapArtClient.BUILDER;
        MapArtGrid grid = builder.getGrid();

        if (grid != null) {
            Map<Item, Integer> req = grid.summarizeRequiredItems();
            totalBlocks  = req.values().stream().mapToInt(Integer::intValue).sum();
            // Tien do realtime tu AutoBuilder (o trong cung tinh la da xu ly, nen dung tong o thay vi totalBlocks)
            builtBlocks  = builder.getCompletedCount();
            progressTotal = builder.getTotalCount() > 0 ? builder.getTotalCount() : grid.totalCells();
            String src   = builder.getSourceImagePath();
            imageName    = src != null ? shortName(src) : "(anh hien tai)";
            sizeLabel    = grid.width + " x " + grid.height + " block";

            Set<Item> inInv = inventoryItems();
            for (Map.Entry<Item, Integer> e : req.entrySet()) {
                int cnt   = e.getValue();
                int stacks = (cnt + 63) / 64;
                Identifier id = Registries.ITEM.getId(e.getKey());
                rows.add(new ItemRow(e.getKey(), id, cnt, stacks, inInv.contains(e.getKey())));
            }
        } else {
            imageName = "(chua convert anh nao)";
        }
    }

    private Set<Item> inventoryItems() {
        Set<Item> set = new HashSet<>();
        if (client == null || client.player == null) return set;
        var inv = client.player.getInventory();
        for (int i = 0; i < 36; i++) { // hotbar 0-8 + inventory chinh 9-35 (giong InventoryHelper)
            ItemStack s = inv.getStack(i);
            if (!s.isEmpty()) set.add(s.getItem());
        }
        return set;
    }

    private String builderLabel() {
        AutoBuilder b = MapArtClient.BUILDER;
        return (b != null && b.isActive()) ? "■ Stop" : "▶ Resume";
    }

    private void onStopResume() {
        AutoBuilder b = MapArtClient.BUILDER;
        if (b == null) return;
        if (b.isActive()) {
            if (client != null) b.stop(client);
        } else if (client != null && client.player != null) {
            client.player.networkHandler.sendChatCommand("mapart resume");
        }
        stopResumeBtn.setMessage(Text.literal(builderLabel()));
    }

    private static String shortName(String path) {
        int i = Math.max(path.lastIndexOf('/'), path.lastIndexOf('\\'));
        return i >= 0 ? path.substring(i + 1) : path;
    }

    // ===== RENDER =====

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        // Nen mo
        ctx.fillGradient(0, 0, width, height, 0x88000000, 0x99000000);

        // Vien + nen panel
        ctx.fill(panelX - 1, panelY - 1, panelX + PANEL_W + 1, panelY + panelH + 1, BORDER);
        ctx.fill(panelX, panelY, panelX + PANEL_W, panelY + panelH, PANEL_BG);

        drawHeader(ctx);
        drawList(ctx, mouseX, mouseY);
        drawScrollbar(ctx);
        drawFooter(ctx);

        // Render nut bam (super.render sau cung de nut noi len tren)
        super.render(ctx, mouseX, mouseY, delta);
    }

    private void drawHeader(DrawContext ctx) {
        // Thanh accent tren cung
        ctx.fill(panelX, panelY, panelX + PANEL_W, panelY + 3, ACCENT);

        int x = panelX + 10;
        int y = panelY + 8;
        ctx.drawText(textRenderer, "§b§lMapArt §r§8| §7Danh sach block", x, y, TEXT_WHITE, false);

        y += 12;
        ctx.drawText(textRenderer, "§e" + imageName + "  §8" + sizeLabel, x, y, TEXT_GRAY, false);

        y += 11;
        if (progressTotal > 0) {
            drawBar(ctx, x, y, PANEL_W - 20, 6, builtBlocks, progressTotal);
            y += 9;
            ctx.drawText(textRenderer,
                    String.format("§7%.1f%%  (%d / %d o da xu ly)", 100.0 * builtBlocks / progressTotal, builtBlocks, progressTotal),
                    x, y, TEXT_GRAY, false);
        } else {
            ctx.drawText(textRenderer, "§cChua co grid. Go /mapart build truoc.", x, y, TEXT_GRAY, false);
        }

        ctx.fill(panelX, panelY + HEADER_H - 1, panelX + PANEL_W, panelY + HEADER_H, BORDER);
    }

    private void drawList(DrawContext ctx, int mouseX, int mouseY) {
        if (rows.isEmpty()) {
            ctx.drawText(textRenderer, "§7(khong co item nao)", panelX + 12, listY + 8, TEXT_GRAY, false);
            return;
        }

        int clipX2 = panelX + PANEL_W - SCROLL_W - 6;
        int end    = Math.min(scrollOffset + visibleRows, rows.size());

        for (int i = scrollOffset; i < end; i++) {
            ItemRow row = rows.get(i);
            int ry      = listY + (i - scrollOffset) * ROW_H;

            boolean hovered = mouseX >= panelX + 4 && mouseX < clipX2
                    && mouseY >= ry && mouseY < ry + ROW_H;
            if (hovered) ctx.fill(panelX + 4, ry, clipX2, ry + ROW_H - 1, 0x22FFFFFF);

            if (i > scrollOffset)
                ctx.fill(panelX + 8, ry, clipX2 - 4, ry + 1, 0x18FFFFFF);

            // so thu tu
            ctx.drawText(textRenderer, String.format("%2d.", i + 1),
                    panelX + 5, ry + 7, TEXT_GRAY, false);

            // icon item
            int iconX = panelX + 22;
            int iconY = ry + (ROW_H - ICON_SZ) / 2;
            try { ctx.drawItem(new ItemStack(row.item()), iconX, iconY); } catch (Exception ignored) {}

            // ten block (bo namespace minecraft:, giu modded)
            String name = row.id().getPath().replace('_', ' ');
            int nameColor = row.inInventory() ? TEXT_GREEN : TEXT_WHITE;
            ctx.drawText(textRenderer, name, panelX + 42, ry + 4, nameColor, false);

            // namespace neu khong phai minecraft
            if (!"minecraft".equals(row.id().getNamespace())) {
                ctx.drawText(textRenderer, "§8" + row.id().getNamespace(),
                        panelX + 42, ry + 13, TEXT_GRAY, false);
            }

            // so luong + stack can phai
            String qty = row.count() + " §8(~" + row.stacks() + " stk)";
            int qw = textRenderer.getWidth(row.count() + " (~" + row.stacks() + " stk)");
            ctx.drawText(textRenderer, qty, clipX2 - qw - 4, ry + 7, TEXT_YELLOW, false);
        }
    }

    private void drawScrollbar(DrawContext ctx) {
        if (rows.size() <= visibleRows) return;
        int sbX = panelX + PANEL_W - SCROLL_W - 2;
        ctx.fill(sbX, listY, sbX + SCROLL_W, listY + listH, BAR_BG);

        float ratio  = (float) visibleRows / rows.size();
        int thumbH   = Math.max(18, (int)(listH * ratio));
        int maxOff   = rows.size() - visibleRows;
        int thumbY   = listY + (maxOff == 0 ? 0 : (int)((listH - thumbH) * (float)scrollOffset / maxOff));
        ctx.fill(sbX + 1, thumbY + 1, sbX + SCROLL_W - 1, thumbY + thumbH - 1, 0xFFBBBBBB);
    }

    private void drawFooter(DrawContext ctx) {
        int fy = panelY + panelH - FOOTER_H;
        ctx.fill(panelX, fy, panelX + PANEL_W, fy + 1, BORDER);
        ctx.fill(panelX, fy + 1, panelX + PANEL_W, panelY + panelH, 0xCC111111);

        String summary = rows.size() + " loai block  |  " + totalBlocks + " o tong cong";
        ctx.drawText(textRenderer, summary,
                panelX + PANEL_W / 2 - textRenderer.getWidth(summary) / 2,
                fy + 4, TEXT_GRAY, false);
    }

    private void drawBar(DrawContext ctx, int x, int y, int w, int h, int cur, int total) {
        ctx.fill(x, y, x + w, y + h, BAR_BG);
        if (total <= 0) return;
        float f    = Math.min(1f, (float)cur / total);
        int fill   = (int)(w * f);
        int color  = f > 0.9f ? BAR_CYAN : f > 0.5f ? BAR_YELLOW : BAR_GREEN;
        if (fill > 0) ctx.fill(x, y, x + fill, y + h, color);
    }

    // ===== INPUT =====

    @Override
    public boolean mouseScrolled(double mx, double my, double hAmt, double vAmt) {
        scroll((int)-vAmt);
        return true;
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == org.lwjgl.glfw.GLFW.GLFW_KEY_UP)   { scroll(-1); return true; }
        if (key == org.lwjgl.glfw.GLFW.GLFW_KEY_DOWN) { scroll(1);  return true; }
        if (key == org.lwjgl.glfw.GLFW.GLFW_KEY_M)    { close();    return true; }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int btn) {
        int sbX = panelX + PANEL_W - SCROLL_W - 2;
        if (mx >= sbX && mx <= sbX + SCROLL_W && my >= listY && my <= listY + listH) {
            dragging = true; dragStartY = my; dragStartOffset = scrollOffset;
            return true;
        }
        return super.mouseClicked(mx, my, btn);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int btn, double dx, double dy) {
        if (dragging && rows.size() > visibleRows) {
            int maxOff = rows.size() - visibleRows;
            int newOff = dragStartOffset + (int)((my - dragStartY) / listH * rows.size());
            scrollOffset = Math.max(0, Math.min(maxOff, newOff));
            return true;
        }
        return super.mouseDragged(mx, my, btn, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int btn) {
        dragging = false;
        return super.mouseReleased(mx, my, btn);
    }

    private void scroll(int d) {
        int maxOff = Math.max(0, rows.size() - visibleRows);
        scrollOffset = Math.max(0, Math.min(maxOff, scrollOffset + d));
    }

    @Override
    public void tick() {
        // Cap nhat tien do + nhan nut Stop/Resume theo trang thai that (khong can dong/mo lai GUI)
        AutoBuilder b = MapArtClient.BUILDER;
        if (b != null && b.getGrid() != null) {
            builtBlocks = b.getCompletedCount();
            if (b.getTotalCount() > 0) progressTotal = b.getTotalCount();
        }
        if (stopResumeBtn != null) stopResumeBtn.setMessage(Text.literal(builderLabel()));
    }

    @Override
    public boolean shouldPause() { return false; }
}
