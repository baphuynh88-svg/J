package com.bro.mapart;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Hang chua cac hang so / logger dung chung cho toan mod.
 * Khong co logic init o day - logic khoi tao that su nam trong MapArtClient
 * vi day la mod client-only.
 */
public class MapArtMod {
    public static final String MOD_ID = "mapart-builder";
    public static final Logger LOGGER = LoggerFactory.getLogger("MapArtBuilder");
}
