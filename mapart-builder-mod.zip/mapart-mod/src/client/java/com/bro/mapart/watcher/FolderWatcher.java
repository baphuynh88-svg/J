package com.bro.mapart.watcher;

import com.bro.mapart.MapArtMod;

import java.io.File;
import java.io.IOException;
import java.nio.file.*;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;

import static java.nio.file.StandardWatchEventKinds.*;

/**
 * Theo doi mot thu muc, khi phat hien file anh moi duoc them vao thi goi
 * callback voi file do. Chay tren thread rieng, khong chan main thread.
 */
public class FolderWatcher {

    private static final Set<String> IMAGE_EXTENSIONS = Set.of("png", "jpg", "jpeg", "bmp", "gif");

    private final Path watchDir;
    private final Consumer<File> onNewImage;
    private Thread thread;
    private final AtomicBoolean running = new AtomicBoolean(false);

    public FolderWatcher(Path watchDir, Consumer<File> onNewImage) {
        this.watchDir = watchDir;
        this.onNewImage = onNewImage;
    }

    public void start() {
        if (running.get()) return;
        try {
            Files.createDirectories(watchDir);
        } catch (IOException e) {
            MapArtMod.LOGGER.error("[MapArt] Khong the tao thu muc theo doi: " + watchDir, e);
            return;
        }

        running.set(true);
        thread = new Thread(this::watchLoop, "MapArt-FolderWatcher");
        thread.setDaemon(true);
        thread.start();
        MapArtMod.LOGGER.info("[MapArt] Dang theo doi thu muc: {}", watchDir.toAbsolutePath());
    }

    public void stop() {
        running.set(false);
        if (thread != null) {
            thread.interrupt();
        }
    }

    private void watchLoop() {
        try (WatchService watchService = FileSystems.getDefault().newWatchService()) {
            watchDir.register(watchService, ENTRY_CREATE, ENTRY_MODIFY);

            while (running.get()) {
                WatchKey key;
                try {
                    key = watchService.poll(1, java.util.concurrent.TimeUnit.SECONDS);
                } catch (InterruptedException e) {
                    break;
                }
                if (key == null) continue;

                for (WatchEvent<?> event : key.pollEvents()) {
                    if (event.kind() == OVERFLOW) continue;

                    @SuppressWarnings("unchecked")
                    WatchEvent<Path> pathEvent = (WatchEvent<Path>) event;
                    Path fileName = pathEvent.context();
                    Path fullPath = watchDir.resolve(fileName);

                    if (isImageFile(fullPath)) {
                        // Doi 1 chut de dam bao file da ghi xong (tranh doc file dang copy dang)
                        waitForFileStable(fullPath);
                        File file = fullPath.toFile();
                        if (file.exists() && onNewImage != null) {
                            onNewImage.accept(file);
                        }
                    }
                }

                boolean valid = key.reset();
                if (!valid) break;
            }
        } catch (IOException e) {
            MapArtMod.LOGGER.error("[MapArt] Loi WatchService.", e);
        }
    }

    private boolean isImageFile(Path path) {
        String name = path.getFileName().toString().toLowerCase();
        int dot = name.lastIndexOf('.');
        if (dot < 0) return false;
        String ext = name.substring(dot + 1);
        return IMAGE_EXTENSIONS.contains(ext);
    }

    /**
     * Doi den khi kich thuoc file khong doi trong 2 lan check lien tiep,
     * tranh doc file dang duoc copy/ghi do (chua hoan chinh).
     */
    private void waitForFileStable(Path path) {
        try {
            long lastSize = -1;
            for (int i = 0; i < 20; i++) { // toi da ~4 giay
                long size = Files.size(path);
                if (size == lastSize && size > 0) return;
                lastSize = size;
                Thread.sleep(200);
            }
        } catch (IOException | InterruptedException ignored) {
        }
    }
}
