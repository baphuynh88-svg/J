package com.bro.mapart.image;

import com.bro.mapart.color.BlockColorEntry;
import com.bro.mapart.color.BlockPaletteBuilder;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.List;

/**
 * Doc file anh tu dia, resize ve kich thuoc mong muon (so block rong/cao),
 * roi map tung pixel sang block gan mau nhat trong bang mau.
 */
public class ImageConverter {

    public static class ConversionException extends Exception {
        public ConversionException(String msg) {
            super(msg);
        }
    }

    /**
     * @param imageFile file anh nguon (png/jpg/...)
     * @param targetWidth  so block theo chieu rong (truc X)
     * @param targetHeight so block theo chieu cao anh (truc Z)
     * @param palette bang mau da build san
     */
    public static MapArtGrid convert(File imageFile, int targetWidth, int targetHeight,
                                      List<BlockColorEntry> palette) throws ConversionException {
        if (!imageFile.exists()) {
            throw new ConversionException("Khong tim thay file anh: " + imageFile.getAbsolutePath());
        }

        BufferedImage original;
        try {
            original = ImageIO.read(imageFile);
        } catch (IOException e) {
            throw new ConversionException("Loi doc file anh: " + e.getMessage());
        }
        if (original == null) {
            throw new ConversionException("Dinh dang anh khong duoc ho tro: " + imageFile.getName());
        }

        BufferedImage resized = resize(original, targetWidth, targetHeight);

        MapArtGrid grid = new MapArtGrid(targetWidth, targetHeight);
        for (int z = 0; z < targetHeight; z++) {
            for (int x = 0; x < targetWidth; x++) {
                int argb = resized.getRGB(x, z);
                int alpha = (argb >> 24) & 0xFF;
                int r = (argb >> 16) & 0xFF;
                int g = (argb >> 8) & 0xFF;
                int b = argb & 0xFF;

                if (alpha < 64) {
                    // pixel trong suot -> bo qua o nay (khong dat block)
                    grid.set(x, z, null);
                    continue;
                }

                BlockColorEntry closest = BlockPaletteBuilder.findClosest(palette, r, g, b);
                grid.set(x, z, closest);
            }
        }

        return grid;
    }

    private static BufferedImage resize(BufferedImage src, int w, int h) {
        BufferedImage resized = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = resized.createGraphics();
        g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g2d.drawImage(src, 0, 0, w, h, null);
        g2d.dispose();
        return resized;
    }
}
