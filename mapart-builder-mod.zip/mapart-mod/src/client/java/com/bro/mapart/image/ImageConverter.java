package com.bro.mapart.image;

import com.bro.mapart.color.BlockColorEntry;
import com.bro.mapart.color.BlockPaletteBuilder;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.List;

/**
 * Doc file anh tu dia, resize ve kich thuoc mong muon (so block rong/cao),
 * roi map tung pixel sang block gan mau nhat trong bang mau.
 *
 * Cai tien so voi ban cu:
 *  - Resize nhieu buoc (giam dan 1/2) de giu chi tiet, tranh rang cua / nhoe mau.
 *  - Nen trang o RIA anh (noi lien voi mep) duoc coi la nen -> khong dat block.
 *    Pixel trang nam giua anh (highlight trong logo) van duoc giu.
 *  - Ho tro Floyd-Steinberg dithering (tat mac dinh) cho anh nhieu sac do.
 *  - Cache ket qua findClosest theo mau de convert nhanh hon nhieu.
 */
public class ImageConverter {

    /** Bat dithering Floyd-Steinberg. Voi logo/flat-color nen de false (sac net hon). */
    public static boolean USE_DITHERING = false;

    /** Pixel gan trang (moi kenh >= nguong nay) nam o RIA anh se duoc coi la nen. */
    private static final int BG_WHITE_THRESHOLD = 235;

    public static class ConversionException extends Exception {
        public ConversionException(String msg) {
            super(msg);
        }
    }

    /**
     * @param imageFile file anh nguon (png/jpg/...)
     * @param targetWidth  so block theo chieu rong (truc X)
     * @param targetHeight so block theo chieu cao anh (truc Z)
     * @param palette bang mau da build san
     */
    public static MapArtGrid convert(File imageFile, int targetWidth, int targetHeight,
                                      List<BlockColorEntry> palette) throws ConversionException {
        if (!imageFile.exists()) {
            throw new ConversionException("Khong tim thay file anh: " + imageFile.getAbsolutePath());
        }
        if (palette == null || palette.isEmpty()) {
            throw new ConversionException("Bang mau rong (chua co block nao hop le).");
        }

        BufferedImage original;
        try {
            original = ImageIO.read(imageFile);
        } catch (IOException e) {
            throw new ConversionException("Loi doc file anh: " + e.getMessage());
        }
        if (original == null) {
            throw new ConversionException("Dinh dang anh khong duoc ho tro: " + imageFile.getName());
        }

        BufferedImage resized = resizeHighQuality(original, targetWidth, targetHeight);

        boolean[][] isBackground = detectBackground(resized, targetWidth, targetHeight);
        float[][][] rgb = new float[targetHeight][targetWidth][3];
        for (int z = 0; z < targetHeight; z++) {
            for (int x = 0; x < targetWidth; x++) {
                int argb = resized.getRGB(x, z);
                rgb[z][x][0] = (argb >> 16) & 0xFF;
                rgb[z][x][1] = (argb >> 8) & 0xFF;
                rgb[z][x][2] = argb & 0xFF;
            }
        }

        MapArtGrid grid = new MapArtGrid(targetWidth, targetHeight);
        java.util.HashMap<Integer, BlockColorEntry> cache = new java.util.HashMap<>();

        for (int z = 0; z < targetHeight; z++) {
            for (int x = 0; x < targetWidth; x++) {
                if (isBackground[z][x]) {
                    grid.set(x, z, null);
                    continue;
                }

                int r = clamp(Math.round(rgb[z][x][0]));
                int g = clamp(Math.round(rgb[z][x][1]));
                int b = clamp(Math.round(rgb[z][x][2]));

                int key = (r << 16) | (g << 8) | b;
                BlockColorEntry closest = cache.get(key);
                if (closest == null) {
                    closest = BlockPaletteBuilder.findClosest(palette, r, g, b);
                    cache.put(key, closest);
                }
                grid.set(x, z, closest);

                if (USE_DITHERING && closest != null) {
                    float er = rgb[z][x][0] - closest.r;
                    float eg = rgb[z][x][1] - closest.g;
                    float eb = rgb[z][x][2] - closest.b;
                    diffuse(rgb, isBackground, x + 1, z,     targetWidth, targetHeight, er, eg, eb, 7f / 16f);
                    diffuse(rgb, isBackground, x - 1, z + 1, targetWidth, targetHeight, er, eg, eb, 3f / 16f);
                    diffuse(rgb, isBackground, x,     z + 1, targetWidth, targetHeight, er, eg, eb, 5f / 16f);
                    diffuse(rgb, isBackground, x + 1, z + 1, targetWidth, targetHeight, er, eg, eb, 1f / 16f);
                }
            }
        }

        if (!USE_DITHERING) {
            cleanupIsolated(grid, targetWidth, targetHeight);
        }
        return grid;
    }

    /**
     * Lam sach nhieu o vien: pixel anti-alias giua 2 vung mau (vd navy va cyan) hay bi map
     * sang block "la" (xanh la, teal, ...). Neu 1 o khac tat ca >= 6/8 o lang gieng
     * xung quanh (va cac o do dong nhat voi nhau), doi no thanh block da so.
     * Chay 2 luot, khong dung khi bat dithering (dithering chu y tao nhieu).
     */
    private static void cleanupIsolated(MapArtGrid grid, int w, int h) {
        for (int pass = 0; pass < 2; pass++) {
            BlockColorEntry[][] snapshot = new BlockColorEntry[w][h];
            for (int x = 0; x < w; x++) {
                for (int z = 0; z < h; z++) snapshot[x][z] = grid.get(x, z);
            }
            for (int x = 1; x < w - 1; x++) {
                for (int z = 1; z < h - 1; z++) {
                    BlockColorEntry cur = snapshot[x][z];
                    if (cur == null) continue;

                    java.util.HashMap<BlockColorEntry, Integer> votes = new java.util.HashMap<>();
                    int nonNull = 0;
                    for (int dx = -1; dx <= 1; dx++) {
                        for (int dz = -1; dz <= 1; dz++) {
                            if (dx == 0 && dz == 0) continue;
                            BlockColorEntry n = snapshot[x + dx][z + dz];
                            if (n == null) continue;
                            nonNull++;
                            votes.merge(n, 1, Integer::sum);
                        }
                    }
                    if (nonNull < 6) continue;

                    BlockColorEntry top = null;
                    int topVotes = 0;
                    for (java.util.Map.Entry<BlockColorEntry, Integer> e : votes.entrySet()) {
                        if (e.getValue() > topVotes) {
                            topVotes = e.getValue();
                            top = e.getKey();
                        }
                    }
                    if (top != null && top != cur && topVotes >= 6 && !votes.containsKey(cur)) {
                        grid.set(x, z, top);
                    }
                }
            }
        }
    }

    private static void diffuse(float[][][] rgb, boolean[][] bg, int x, int z, int w, int h,
                                float er, float eg, float eb, float factor) {
        if (x < 0 || x >= w || z < 0 || z >= h) return;
        if (bg[z][x]) return;
        rgb[z][x][0] += er * factor;
        rgb[z][x][1] += eg * factor;
        rgb[z][x][2] += eb * factor;
    }

    /**
     * Xac dinh o nao la "nen": alpha thap, HOAC gan trang va noi lien voi
     * mep anh (flood fill tu 4 canh).
     */
    private static boolean[][] detectBackground(BufferedImage img, int w, int h) {
        boolean[][] bg = new boolean[h][w];
        boolean[][] candidate = new boolean[h][w];

        for (int z = 0; z < h; z++) {
            for (int x = 0; x < w; x++) {
                int argb = img.getRGB(x, z);
                int a = (argb >>> 24) & 0xFF;
                int r = (argb >> 16) & 0xFF;
                int g = (argb >> 8) & 0xFF;
                int b = argb & 0xFF;
                boolean transparent = a < 64;
                boolean nearWhite = r >= BG_WHITE_THRESHOLD && g >= BG_WHITE_THRESHOLD && b >= BG_WHITE_THRESHOLD;
                candidate[z][x] = transparent || nearWhite;
            }
        }

        java.util.ArrayDeque<int[]> queue = new java.util.ArrayDeque<>();
        for (int x = 0; x < w; x++) {
            seed(candidate, bg, queue, x, 0);
            seed(candidate, bg, queue, x, h - 1);
        }
        for (int z = 0; z < h; z++) {
            seed(candidate, bg, queue, 0, z);
            seed(candidate, bg, queue, w - 1, z);
        }
        int[] dx = {1, -1, 0, 0};
        int[] dz = {0, 0, 1, -1};
        while (!queue.isEmpty()) {
            int[] p = queue.poll();
            for (int i = 0; i < 4; i++) {
                int nx = p[0] + dx[i];
                int nz = p[1] + dz[i];
                if (nx < 0 || nx >= w || nz < 0 || nz >= h) continue;
                if (bg[nz][nx] || !candidate[nz][nx]) continue;
                bg[nz][nx] = true;
                queue.add(new int[]{nx, nz});
            }
        }

        // Pixel trong suot hoan toan (ke ca nam giua anh) van la "khong dat block"
        for (int z = 0; z < h; z++) {
            for (int x = 0; x < w; x++) {
                int a = (img.getRGB(x, z) >>> 24) & 0xFF;
                if (a < 64) bg[z][x] = true;
            }
        }
        return bg;
    }

    private static void seed(boolean[][] candidate, boolean[][] bg,
                             java.util.ArrayDeque<int[]> queue, int x, int z) {
        if (candidate[z][x] && !bg[z][x]) {
            bg[z][x] = true;
            queue.add(new int[]{x, z});
        }
    }

    /** Resize giam dan tung buoc 1/2 (bilinear) roi buoc cuoi ve dung kich thuoc. */
    private static BufferedImage resizeHighQuality(BufferedImage src, int w, int h) {
        BufferedImage cur = toArgb(src);
        int cw = cur.getWidth();
        int ch = cur.getHeight();

        while (cw / 2 >= w && ch / 2 >= h) {
            cw = cw / 2;
            ch = ch / 2;
            cur = scale(cur, cw, ch);
        }
        if (cw != w || ch != h) {
            cur = scale(cur, w, h);
        }
        return cur;
    }

    private static BufferedImage toArgb(BufferedImage src) {
        BufferedImage out = new BufferedImage(src.getWidth(), src.getHeight(), BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = out.createGraphics();
        g.drawImage(src, 0, 0, null);
        g.dispose();
        return out;
    }

    private static BufferedImage scale(BufferedImage src, int w, int h) {
        BufferedImage out = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = out.createGraphics();
        g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.drawImage(src, 0, 0, w, h, null);
        g2d.dispose();
        return out;
    }

    private static int clamp(int v) {
        return v < 0 ? 0 : Math.min(v, 255);
    }
}
