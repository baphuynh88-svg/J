package com.bro.mapart.image;

import com.bro.mapart.color.BlockColorEntry;
import com.bro.mapart.color.BlockPaletteBuilder;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.List;

/**
 * Doc anh, resize, roi map sang block. Thuat toan 2 tang (v2) de vua CHI TIET vua DUNG MAU:
 *
 *  1. Lam mượt anh (median 3x3, x2) de khu nhieu JPEG => dung cho vung PHANG.
 *  2. Chon "palette con" (K block) bang GREEDY: lan luot them block lam GIAM SAI SO tong nhieu nhat,
 *     nen block hiem nhung quan trong (nau-tro cua toc, hong cua mat, do cua ao) van duoc chon,
 *     khong bi "top-dem" nuot mat.
 *  3. Phat hien CANH (do sang + mau): net vien, mieng, sao trong mat, highlight, hoa tren mu.
 *     O canh => lay pixel GOC, nearest truc tiep tren palette con (giu net 1 block).
 *  4. Vung PHANG => chia thanh cac manh (SLIC-lite theo luoi + mau). Moi manh chon block gan nhat.
 *     Neu mau trung binh cua manh nam GIUA 2 block (vd nau-tro nam giua xam va hong), va vung TOI,
 *     thi tron 2 block theo ma tran Bayer 4x4 => ra dung tong mau (thay vi bi ep sang xam/hong).
 *     Vung SANG (da/ma) giu 1 block dac cho sach.
 *  5. Loc mode 3x3 chi o vung phang (xoa o le loi), khong dong vao canh.
 *
 * Deterministic hoan toan (khong Random) => /mapart resume convert lai ra dung luoi nhu lan dau.
 */
public class ImageConverter {

    /** So block trong palette con (cang cao cang du sac thai, nhung nhieu loai block phai chuan bi hon). */
    public static int PALETTE_K = 28;

    /** Trong so khi chon block theo Lab: L (do sang), a/b (sac do). C > L => uu tien dung hue. */
    public static double W_L = 1.0;
    public static double W_C = 1.6;

    /** Nguong phat hien canh (gradient do sang / gradient mau). Giam => nhieu o duoc coi la chi tiet hon. */
    public static double EDGE_L_THRESHOLD = 7.0;
    public static double EDGE_C_THRESHOLD = 9.0;

    /** Bat tron Bayer o vung phang. Tat => vung phang chi 1 block/manh (sach nhung mat tong mau). */
    public static boolean USE_BAYER_BLEND = true;
    /** Chi tron khi do sang (L*) cua manh < nguong nay; vung sang giu 1 block dac. */
    public static double BLEND_MAX_LIGHTNESS = 78.0;
    /** Vung qua toi (L* < nguong) khong tron: mat nguoi khong phan biet duoc hue, chi lam roi (vd mu den). */
    public static double BLEND_MIN_LIGHTNESS = 35.0;
    /** Chroma (sqrt(a^2+b^2)) toi thieu cua manh de duoc tron; tang len khi vung toi. */
    public static double BLEND_MIN_CHROMA = 8.0;
    /** Khoang cach Lab toi da giua 2 block trong 1 cap tron. */
    public static double BLEND_MAX_PAIR = 40.0;
    /** Sai so toi da (Lab) cho phep giua mau manh va mau tron ra tu cap; vuot => dung 1 block gan nhat. */
    public static double BLEND_MAX_RESIDUAL = 5.0;
    /** Manh co ~ (chiều rong) o vuong; so manh ~ (w*h)/SEGMENT_AREA. */
    public static int SEGMENT_AREA = 60;

    /** Pixel gan trang (moi kenh >= nguong nay) nam o RIA anh se duoc coi la nen. */
    private static final int BG_WHITE_THRESHOLD = 235;

    private static final double[][] BAYER4 = buildBayer4();

    public static class ConversionException extends Exception {
        public ConversionException(String msg) {
            super(msg);
        }
    }

    public static MapArtGrid convert(File imageFile, int targetWidth, int targetHeight,
                                      List<BlockColorEntry> palette) throws ConversionException {
        if (!imageFile.exists()) {
            throw new ConversionException("Khong tim thay file anh: " + imageFile.getAbsolutePath());
        }
        if (palette == null || palette.isEmpty()) {
            throw new ConversionException("Bang mau rong (chua co block nao hop le).");
        }

        BufferedImage original;
        try {
            original = ImageIO.read(imageFile);
        } catch (IOException e) {
            throw new ConversionException("Loi doc file anh: " + e.getMessage());
        }
        if (original == null) {
            throw new ConversionException("Dinh dang anh khong duoc ho tro: " + imageFile.getName());
        }

        BufferedImage resized = resizeHighQuality(original, targetWidth, targetHeight);
        boolean[][] bg = detectBackground(resized, targetWidth, targetHeight);
        return convertHybrid(resized, bg, targetWidth, targetHeight, palette);
    }

    // ------------------------------------------------------------------
    //  Thuat toan chinh
    // ------------------------------------------------------------------

    private static MapArtGrid convertHybrid(BufferedImage img, boolean[][] bg, int w, int h,
                                            List<BlockColorEntry> palette) {
        MapArtGrid grid = new MapArtGrid(w, h);

        // --- 1) Anh goc + anh lam mượt (Lab) ---
        int[][] rgb = new int[h][w];
        for (int z = 0; z < h; z++) {
            for (int x = 0; x < w; x++) rgb[z][x] = img.getRGB(x, z) & 0xFFFFFF;
        }
        int[][] smoothRgb = medianFilter(medianFilter(rgb, bg, w, h), bg, w, h);

        double[][][] labRaw = new double[h][w][];
        double[][][] labSm = new double[h][w][];
        int n = 0;
        for (int z = 0; z < h; z++) {
            for (int x = 0; x < w; x++) {
                labRaw[z][x] = toLab(rgb[z][x]);
                labSm[z][x] = toLab(smoothRgb[z][x]);
                if (!bg[z][x]) n++;
            }
        }
        if (n == 0) return grid;

        // --- 2) Palette con (K block) chon bang greedy ---
        int pn = palette.size();
        double[][] plab = new double[pn][];
        for (int i = 0; i < pn; i++) {
            BlockColorEntry e = palette.get(i);
            plab[i] = BlockColorEntry.rgbToLab(e.r, e.g, e.b);
        }
        int[] sub = greedySubset(labSm, bg, w, h, plab, Math.max(2, Math.min(PALETTE_K, pn)));
        int sk = sub.length;
        double[][] slab = new double[sk][];
        for (int i = 0; i < sk; i++) slab[i] = plab[sub[i]];

        // --- 3) Canh ---
        boolean[][] edge = detectEdges(labRaw, bg, w, h);

        // --- 4a) Chi tiet: nearest tren pixel goc (idx trong sub) ---
        int[][] detail = new int[h][w];
        for (int z = 0; z < h; z++) {
            for (int x = 0; x < w; x++) {
                detail[z][x] = bg[z][x] ? -1 : nearestIdx(labRaw[z][x], slab);
            }
        }

        // --- 4b) Vung phang: manh + (tuy chon) tron Bayer ---
        int[][] flat = new int[h][w];
        for (int[] row : flat) java.util.Arrays.fill(row, -1);
        int[][] seg = buildSegments(labSm, bg, w, h);
        int segCount = 0;
        for (int[] row : seg) for (int v : row) if (v + 1 > segCount) segCount = v + 1;

        double[][] sum = new double[segCount][3];
        int[] cnt = new int[segCount];
        for (int z = 0; z < h; z++) {
            for (int x = 0; x < w; x++) {
                if (bg[z][x] || edge[z][x]) continue;
                int s = seg[z][x];
                if (s < 0) continue;
                sum[s][0] += labSm[z][x][0];
                sum[s][1] += labSm[z][x][1];
                sum[s][2] += labSm[z][x][2];
                cnt[s]++;
            }
        }
        int[] b1 = new int[segCount];
        int[] b2 = new int[segCount];
        double[] tMix = new double[segCount];
        boolean[] blend = new boolean[segCount];
        for (int s = 0; s < segCount; s++) {
            if (cnt[s] == 0) continue;
            double[] mean = {sum[s][0] / cnt[s], sum[s][1] / cnt[s], sum[s][2] / cnt[s]};
            // Block don gan nhat (dung khi khong tron)
            int s1 = 0;
            double sd = Double.MAX_VALUE;
            for (int j = 0; j < sk; j++) {
                double d = wdist2(mean, slab[j]);
                if (d < sd) { sd = d; s1 = j; }
            }
            // Chon CAP (a,c) tron ra DUNG mau manh nhat (residual nho nhat), khong phai 2 block gan nhat:
            // vd toc nau-tro = stone_bricks + purple_terracotta, du purple_terracotta khong phai la block "gan nhat".
            int ba = -1, bc = -1;
            double bestScore = Double.MAX_VALUE, bestT = 0, bestRes = 0;
            for (int a = 0; a < sk; a++) {
                for (int c = a + 1; c < sk; c++) {
                    double vx = slab[c][0] - slab[a][0], vy = slab[c][1] - slab[a][1], vz = slab[c][2] - slab[a][2];
                    double vv = vx * vx + vy * vy + vz * vz;
                    if (vv < 1e-6) continue;
                    double pd = Math.sqrt(vv);
                    if (pd > BLEND_MAX_PAIR) continue;
                    double tt = ((mean[0] - slab[a][0]) * vx + (mean[1] - slab[a][1]) * vy + (mean[2] - slab[a][2]) * vz) / vv;
                    if (tt <= 0.12 || tt >= 0.88) continue;
                    double rx = mean[0] - (slab[a][0] + tt * vx);
                    double ry = mean[1] - (slab[a][1] + tt * vy);
                    double rz = mean[2] - (slab[a][2] + tt * vz);
                    double res = Math.sqrt(rx * rx + ry * ry + rz * rz);
                    double score = res + 0.02 * pd;
                    if (score < bestScore) { bestScore = score; ba = a; bc = c; bestT = tt; bestRes = res; }
                }
            }
            if (ba < 0 || bestRes > BLEND_MAX_RESIDUAL) {
                b1[s] = s1; b2[s] = s1; tMix[s] = 0; blend[s] = false;
                continue;
            }
            b1[s] = ba;
            b2[s] = bc;
            tMix[s] = bestT;
            double chroma = Math.hypot(mean[1], mean[2]);
            double need = BLEND_MIN_CHROMA * (1.0 + Math.max(0.0, 50.0 - mean[0]) / 25.0);
            blend[s] = USE_BAYER_BLEND && mean[0] < BLEND_MAX_LIGHTNESS
                    && mean[0] >= BLEND_MIN_LIGHTNESS && chroma >= need;
        }
        for (int z = 0; z < h; z++) {
            for (int x = 0; x < w; x++) {
                if (bg[z][x] || edge[z][x]) continue;
                int s = seg[z][x];
                if (s < 0 || cnt[s] == 0) { flat[z][x] = detail[z][x]; continue; }
                if (blend[s]) {
                    flat[z][x] = BAYER4[z & 3][x & 3] < tMix[s] ? b2[s] : b1[s];
                } else {
                    flat[z][x] = tMix[s] < 0.5 ? b1[s] : b2[s];
                }
            }
        }

        // --- 5) Gop + loc mode 3x3 CHI o vung phang (bo qua o canh va o dang tron Bayer) ---
        int[][] merged = new int[h][w];
        for (int z = 0; z < h; z++) {
            for (int x = 0; x < w; x++) {
                merged[z][x] = bg[z][x] ? -1 : (edge[z][x] ? detail[z][x] : flat[z][x]);
            }
        }
        int[][] out = new int[h][w];
        int[] tIds = new int[9];
        int[] tCnt = new int[9];
        for (int z = 0; z < h; z++) {
            for (int x = 0; x < w; x++) {
                int cur = merged[z][x];
                out[z][x] = cur;
                if (cur < 0 || edge[z][x]) continue;
                int s = seg[z][x];
                if (s >= 0 && blend[s]) continue; // dang dither co chu dich: dung dong vao
                int m = 0;
                for (int dz = -1; dz <= 1; dz++) {
                    for (int dx = -1; dx <= 1; dx++) {
                        int nx = x + dx, nz = z + dz;
                        if (nx < 0 || nx >= w || nz < 0 || nz >= h) continue;
                        int id = merged[nz][nx];
                        if (id < 0) continue;
                        int j = 0;
                        while (j < m && tIds[j] != id) j++;
                        if (j == m) { tIds[m] = id; tCnt[m] = 0; m++; }
                        tCnt[j]++;
                    }
                }
                int bestCnt = -1, bestId = cur;
                for (int j = 0; j < m; j++) {
                    if (tCnt[j] > bestCnt || (tCnt[j] == bestCnt && tIds[j] == cur)) {
                        bestCnt = tCnt[j];
                        bestId = tIds[j];
                    }
                }
                // Chi doi khi da so ap dao (>=5/9); tranh xoa nhung mang nho co y nghia
                out[z][x] = bestCnt >= 5 ? bestId : cur;
            }
        }

        for (int z = 0; z < h; z++) {
            for (int x = 0; x < w; x++) {
                int id = out[z][x];
                grid.set(x, z, id < 0 ? null : palette.get(sub[id]));
            }
        }
        return grid;
    }

    // ------------------------------------------------------------------
    //  Greedy chon palette con: moi buoc them block lam giam tong sai so nhieu nhat
    // ------------------------------------------------------------------

    private static int[] greedySubset(double[][][] lab, boolean[][] bg, int w, int h,
                                      double[][] plab, int k) {
        // Lay mau toi da ~4000 pixel (deu theo luoi) de nhanh
        java.util.ArrayList<double[]> pts = new java.util.ArrayList<>();
        int total = 0;
        for (int z = 0; z < h; z++) for (int x = 0; x < w; x++) if (!bg[z][x]) total++;
        int step = Math.max(1, total / 4000);
        int c = 0;
        for (int z = 0; z < h; z++) {
            for (int x = 0; x < w; x++) {
                if (bg[z][x]) continue;
                if ((c++ % step) == 0) pts.add(lab[z][x]);
            }
        }
        int np = pts.size();
        int pn = plab.length;
        double[][] d = new double[np][pn];
        for (int i = 0; i < np; i++) {
            for (int j = 0; j < pn; j++) d[i][j] = wdist2(pts.get(i), plab[j]);
        }
        double[] best = new double[np];
        java.util.Arrays.fill(best, 1e18);
        boolean[] used = new boolean[pn];
        int[] chosen = new int[Math.min(k, pn)];
        for (int s = 0; s < chosen.length; s++) {
            int bj = -1;
            double bestSum = Double.MAX_VALUE;
            for (int j = 0; j < pn; j++) {
                if (used[j]) continue;
                double sum = 0;
                for (int i = 0; i < np; i++) sum += Math.min(best[i], d[i][j]);
                if (sum < bestSum) { bestSum = sum; bj = j; }
            }
            if (bj < 0) break;
            used[bj] = true;
            chosen[s] = bj;
            for (int i = 0; i < np; i++) best[i] = Math.min(best[i], d[i][bj]);
        }
        return chosen;
    }

    // ------------------------------------------------------------------
    //  Manh (segment) - luoi + mau, deterministic (SLIC don gian)
    // ------------------------------------------------------------------

    private static int[][] buildSegments(double[][][] lab, boolean[][] bg, int w, int h) {
        int side = Math.max(3, (int) Math.round(Math.sqrt(SEGMENT_AREA)));
        int gw = Math.max(1, (w + side - 1) / side);
        int gh = Math.max(1, (h + side - 1) / side);
        int k = gw * gh;
        double[][] cLab = new double[k][3];
        double[] cx = new double[k];
        double[] cz = new double[k];
        for (int gy = 0; gy < gh; gy++) {
            for (int gx = 0; gx < gw; gx++) {
                int i = gy * gw + gx;
                cx[i] = Math.min(w - 1, gx * side + side / 2.0);
                cz[i] = Math.min(h - 1, gy * side + side / 2.0);
                cLab[i] = lab[(int) cz[i]][(int) cx[i]].clone();
            }
        }
        double m = 9.0; // compactness
        int[][] seg = new int[h][w];
        double[][] dist = new double[h][w];
        for (int it = 0; it < 6; it++) {
            for (double[] row : dist) java.util.Arrays.fill(row, Double.MAX_VALUE);
            for (int[] row : seg) java.util.Arrays.fill(row, -1);
            for (int i = 0; i < k; i++) {
                int x0 = Math.max(0, (int) cx[i] - side);
                int x1 = Math.min(w - 1, (int) cx[i] + side);
                int z0 = Math.max(0, (int) cz[i] - side);
                int z1 = Math.min(h - 1, (int) cz[i] + side);
                for (int z = z0; z <= z1; z++) {
                    for (int x = x0; x <= x1; x++) {
                        if (bg[z][x]) continue;
                        double dc = Math.sqrt(dist2(lab[z][x], cLab[i]));
                        double ds = Math.hypot(x - cx[i], z - cz[i]);
                        double dd = Math.sqrt(dc * dc + (ds / side) * (ds / side) * m * m);
                        if (dd < dist[z][x]) { dist[z][x] = dd; seg[z][x] = i; }
                    }
                }
            }
            double[][] s = new double[k][3];
            double[] sx = new double[k];
            double[] sz = new double[k];
            int[] c = new int[k];
            for (int z = 0; z < h; z++) {
                for (int x = 0; x < w; x++) {
                    int i = seg[z][x];
                    if (i < 0) continue;
                    s[i][0] += lab[z][x][0]; s[i][1] += lab[z][x][1]; s[i][2] += lab[z][x][2];
                    sx[i] += x; sz[i] += z; c[i]++;
                }
            }
            for (int i = 0; i < k; i++) {
                if (c[i] == 0) continue;
                cLab[i][0] = s[i][0] / c[i]; cLab[i][1] = s[i][1] / c[i]; cLab[i][2] = s[i][2] / c[i];
                cx[i] = sx[i] / c[i]; cz[i] = sz[i] / c[i];
            }
        }
        return seg;
    }

    // ------------------------------------------------------------------
    //  Canh: gradient Sobel tren L va tren (a,b), dilate 1 o
    // ------------------------------------------------------------------

    private static boolean[][] detectEdges(double[][][] lab, boolean[][] bg, int w, int h) {
        boolean[][] raw = new boolean[h][w];
        for (int z = 0; z < h; z++) {
            for (int x = 0; x < w; x++) {
                if (bg[z][x]) continue;
                double gxL = sobel(lab, x, z, w, h, 0, true), gzL = sobel(lab, x, z, w, h, 0, false);
                double gxA = sobel(lab, x, z, w, h, 1, true), gzA = sobel(lab, x, z, w, h, 1, false);
                double gxB = sobel(lab, x, z, w, h, 2, true), gzB = sobel(lab, x, z, w, h, 2, false);
                double gL = Math.hypot(gxL, gzL) / 8.0;
                double gC = Math.hypot(gxA, gzA) / 8.0 + Math.hypot(gxB, gzB) / 8.0;
                raw[z][x] = gL > EDGE_L_THRESHOLD || gC > EDGE_C_THRESHOLD;
            }
        }
        boolean[][] out = new boolean[h][w];
        for (int z = 0; z < h; z++) {
            for (int x = 0; x < w; x++) {
                if (!raw[z][x]) continue;
                for (int dz = -1; dz <= 1; dz++) {
                    for (int dx = -1; dx <= 1; dx++) {
                        int nx = x + dx, nz = z + dz;
                        if (nx >= 0 && nx < w && nz >= 0 && nz < h) out[nz][nx] = true;
                    }
                }
            }
        }
        return out;
    }

    private static double sobel(double[][][] lab, int x, int z, int w, int h, int ch, boolean horizontal) {
        double s = 0;
        for (int dz = -1; dz <= 1; dz++) {
            for (int dx = -1; dx <= 1; dx++) {
                int nx = Math.max(0, Math.min(w - 1, x + dx));
                int nz = Math.max(0, Math.min(h - 1, z + dz));
                double v = lab[nz][nx][ch];
                double k;
                if (horizontal) k = dx * (dz == 0 ? 2 : 1);
                else k = dz * (dx == 0 ? 2 : 1);
                s += k * v;
            }
        }
        return s;
    }

    // ------------------------------------------------------------------
    //  Tien ich
    // ------------------------------------------------------------------

    private static double[][] buildBayer4() {
        int[][] m = {{0, 2}, {3, 1}};
        int[][] b = new int[4][4];
        for (int y = 0; y < 4; y++) {
            for (int x = 0; x < 4; x++) {
                b[y][x] = 4 * m[y % 2][x % 2] + m[y / 2][x / 2];
            }
        }
        double[][] out = new double[4][4];
        for (int y = 0; y < 4; y++) for (int x = 0; x < 4; x++) out[y][x] = (b[y][x] + 0.5) / 16.0;
        return out;
    }

    private static double[] toLab(int rgb) {
        return BlockColorEntry.rgbToLab((rgb >> 16) & 0xFF, (rgb >> 8) & 0xFF, rgb & 0xFF);
    }

    private static int nearestIdx(double[] lab, double[][] pal) {
        int best = 0;
        double bd = Double.MAX_VALUE;
        for (int i = 0; i < pal.length; i++) {
            double d = wdist2(lab, pal[i]);
            if (d < bd) { bd = d; best = i; }
        }
        return best;
    }

    /** Binh phuong khoang cach Lab co trong so (L nhe hon a/b => giu hue). */
    private static double wdist2(double[] a, double[] b) {
        double dl = a[0] - b[0], da = a[1] - b[1], db = a[2] - b[2];
        return W_L * dl * dl + W_C * da * da + W_C * db * db;
    }

    private static double dist2(double[] a, double[] b) {
        double d0 = a[0] - b[0], d1 = a[1] - b[1], d2 = a[2] - b[2];
        return d0 * d0 + d1 * d1 + d2 * d2;
    }

    /** Median 3x3 tung kenh (bo qua o nen). */
    private static int[][] medianFilter(int[][] rgb, boolean[][] bg, int w, int h) {
        int[][] out = new int[h][w];
        int[] rs = new int[9], gs = new int[9], bs = new int[9];
        for (int z = 0; z < h; z++) {
            for (int x = 0; x < w; x++) {
                if (bg[z][x]) { out[z][x] = rgb[z][x]; continue; }
                int m = 0;
                for (int dz = -1; dz <= 1; dz++) {
                    for (int dx = -1; dx <= 1; dx++) {
                        int nx = x + dx, nz = z + dz;
                        if (nx < 0 || nx >= w || nz < 0 || nz >= h || bg[nz][nx]) continue;
                        int c = rgb[nz][nx];
                        rs[m] = (c >> 16) & 0xFF; gs[m] = (c >> 8) & 0xFF; bs[m] = c & 0xFF;
                        m++;
                    }
                }
                java.util.Arrays.sort(rs, 0, m);
                java.util.Arrays.sort(gs, 0, m);
                java.util.Arrays.sort(bs, 0, m);
                out[z][x] = (rs[m / 2] << 16) | (gs[m / 2] << 8) | bs[m / 2];
            }
        }
        return out;
    }



    /**
     * Xac dinh o nao la "nen": alpha thap, HOAC gan trang va noi lien voi
     * mep anh (flood fill tu 4 canh).
     */
    private static boolean[][] detectBackground(BufferedImage img, int w, int h) {
        boolean[][] bg = new boolean[h][w];
        boolean[][] candidate = new boolean[h][w];

        for (int z = 0; z < h; z++) {
            for (int x = 0; x < w; x++) {
                int argb = img.getRGB(x, z);
                int a = (argb >>> 24) & 0xFF;
                int r = (argb >> 16) & 0xFF;
                int g = (argb >> 8) & 0xFF;
                int b = argb & 0xFF;
                boolean transparent = a < 64;
                boolean nearWhite = r >= BG_WHITE_THRESHOLD && g >= BG_WHITE_THRESHOLD && b >= BG_WHITE_THRESHOLD;
                candidate[z][x] = transparent || nearWhite;
            }
        }

        java.util.ArrayDeque<int[]> queue = new java.util.ArrayDeque<>();
        for (int x = 0; x < w; x++) {
            seed(candidate, bg, queue, x, 0);
            seed(candidate, bg, queue, x, h - 1);
        }
        for (int z = 0; z < h; z++) {
            seed(candidate, bg, queue, 0, z);
            seed(candidate, bg, queue, w - 1, z);
        }
        int[] dx = {1, -1, 0, 0};
        int[] dz = {0, 0, 1, -1};
        while (!queue.isEmpty()) {
            int[] p = queue.poll();
            for (int i = 0; i < 4; i++) {
                int nx = p[0] + dx[i];
                int nz = p[1] + dz[i];
                if (nx < 0 || nx >= w || nz < 0 || nz >= h) continue;
                if (bg[nz][nx] || !candidate[nz][nx]) continue;
                bg[nz][nx] = true;
                queue.add(new int[]{nx, nz});
            }
        }

        // Pixel trong suot hoan toan (ke ca nam giua anh) van la "khong dat block"
        for (int z = 0; z < h; z++) {
            for (int x = 0; x < w; x++) {
                int a = (img.getRGB(x, z) >>> 24) & 0xFF;
                if (a < 64) bg[z][x] = true;
            }
        }
        return bg;
    }

    private static void seed(boolean[][] candidate, boolean[][] bg,
                             java.util.ArrayDeque<int[]> queue, int x, int z) {
        if (candidate[z][x] && !bg[z][x]) {
            bg[z][x] = true;
            queue.add(new int[]{x, z});
        }
    }



    /** Resize giam dan tung buoc 1/2 (bilinear) roi buoc cuoi ve dung kich thuoc. */
    private static BufferedImage resizeHighQuality(BufferedImage src, int w, int h) {
        BufferedImage cur = toArgb(src);
        int cw = cur.getWidth();
        int ch = cur.getHeight();

        while (cw / 2 >= w && ch / 2 >= h) {
            cw = cw / 2;
            ch = ch / 2;
            cur = scale(cur, cw, ch);
        }
        if (cw != w || ch != h) {
            cur = scale(cur, w, h);
        }
        return cur;
    }

    private static BufferedImage toArgb(BufferedImage src) {
        BufferedImage out = new BufferedImage(src.getWidth(), src.getHeight(), BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = out.createGraphics();
        g.drawImage(src, 0, 0, null);
        g.dispose();
        return out;
    }

    private static BufferedImage scale(BufferedImage src, int w, int h) {
        BufferedImage out = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = out.createGraphics();
        g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.drawImage(src, 0, 0, w, h, null);
        g2d.dispose();
        return out;
    }

    private static int clamp(int v) {
        return v < 0 ? 0 : Math.min(v, 255);
    }
}
