package com.bro.mapart.image;

import com.bro.mapart.color.BlockColorEntry;

/**
 * Luoi block ket qua sau khi convert anh. Toa do (x, z) la toa do tuong doi
 * so voi goc (0,0) cua khu vuc xay, khong phai toa do the gioi thuc.
 */
public class MapArtGrid {
    public final int width;   // theo truc X
    public final int height;  // theo truc Z (nhin tu tren xuong nen "height" cua anh = do sau theo Z)
    public final BlockColorEntry[][] blocks; // [x][z]

    public MapArtGrid(int width, int height) {
        this.width = width;
        this.height = height;
        this.blocks = new BlockColorEntry[width][height];
    }

    public BlockColorEntry get(int x, int z) {
        if (x < 0 || x >= width || z < 0 || z >= height) return null;
        return blocks[x][z];
    }

    public void set(int x, int z, BlockColorEntry entry) {
        if (x < 0 || x >= width || z < 0 || z >= height) return;
        blocks[x][z] = entry;
    }

    public int totalCells() {
        return width * height;
    }
}
