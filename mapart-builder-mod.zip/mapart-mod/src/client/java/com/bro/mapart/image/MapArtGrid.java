package com.bro.mapart.image;

import com.bro.mapart.color.BlockColorEntry;
import net.minecraft.item.Item;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Luoi block ket qua sau khi convert anh. Toa do (x, z) la toa do tuong doi
 * so voi goc (0,0) cua khu vuc xay, khong phai toa do the gioi thuc.
 */
public class MapArtGrid {
    public final int width;   // theo truc X
    public final int height;  // theo truc Z (nhin tu tren xuong nen "height" cua anh = do sau theo Z)
    public final BlockColorEntry[][] blocks; // [x][z]

    public MapArtGrid(int width, int height) {
        this.width = width;
        this.height = height;
        this.blocks = new BlockColorEntry[width][height];
    }

    public BlockColorEntry get(int x, int z) {
        if (x < 0 || x >= width || z < 0 || z >= height) return null;
        return blocks[x][z];
    }

    public void set(int x, int z, BlockColorEntry entry) {
        if (x < 0 || x >= width || z < 0 || z >= height) return;
        blocks[x][z] = entry;
    }

    public int totalCells() {
        return width * height;
    }

    /**
     * Gop toan bo grid thanh danh sach item can, kem so luong o su dung
     * item do. Dung de bao truoc cho nguoi choi biet can chuan bi gi
     * truoc khi bat dau xay (lenh /mapart list), tranh phai doan mo.
     * Sap xep giam dan theo so luong (item can nhieu nhat len dau).
     */
    public Map<Item, Integer> summarizeRequiredItems() {
        Map<Item, Integer> counts = new LinkedHashMap<>();
        for (int x = 0; x < width; x++) {
            for (int z = 0; z < height; z++) {
                BlockColorEntry entry = blocks[x][z];
                if (entry == null) continue;
                counts.merge(entry.item, 1, Integer::sum);
            }
        }
        return counts.entrySet().stream()
                .sorted((a, b) -> b.getValue() - a.getValue())
                .collect(java.util.stream.Collectors.toMap(
                        Map.Entry::getKey, Map.Entry::getValue,
                        (u, v) -> u, LinkedHashMap::new));
    }
}
