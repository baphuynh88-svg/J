package com.bro.mapart;

import com.bro.mapart.build.AutoBuilder;
import com.bro.mapart.color.BlockColorEntry;
import com.bro.mapart.color.BlockPaletteBuilder;
import com.bro.mapart.command.MapArtCommand;
import com.bro.mapart.watcher.FolderWatcher;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

import java.io.File;
import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

public class MapArtClient implements ClientModInitializer {

    public static List<BlockColorEntry> PALETTE;
    public static final AutoBuilder BUILDER = new AutoBuilder();
    public static Path WATCH_FOLDER;
    private static FolderWatcher watcher;
    private static File pendingImage = null;

    private final ScheduledExecutorService bgExecutor = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread t = new Thread(r, "MapArt-Background");
        t.setDaemon(true);
        return t;
    });

    @Override
    public void onInitializeClient() {
        MapArtMod.LOGGER.info("[MapArt] Khoi tao MapArt Auto Builder...");

        WATCH_FOLDER = FabricLoader.getInstance().getGameDir().resolve("mapart_input");

        // Xay bang mau + khoi dong folder watcher tren thread rieng SAU KHI client san sang,
        // vi BlockPaletteBuilder can doc resource manager (chi co sau khi client load xong assets).
        ClientTickEvents.END_CLIENT_TICK.register(this::onFirstReadyTick);

        ClientCommandRegistrationCallback.EVENT.register(MapArtCommand::register);

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (BUILDER.isActive()) {
                BUILDER.tick(client);
            }
            checkPendingImage(client);
        });
    }

    private boolean initialized = false;

    private void onFirstReadyTick(MinecraftClient client) {
        if (initialized) return;
        if (client.getResourceManager() == null) return;
        initialized = true;

        bgExecutor.submit(() -> {
            try {
                PALETTE = BlockPaletteBuilder.buildOrLoadPalette();
            } catch (Exception e) {
                MapArtMod.LOGGER.error("[MapArt] Loi khi build bang mau.", e);
            }

            watcher = new FolderWatcher(WATCH_FOLDER, file -> {
                // Callback nay chay tren thread cua watcher, khong duoc dung truc tiep API MinecraftClient.
                // Danh dau file cho, xu ly thuc su se dien ra tren client thread o checkPendingImage().
                synchronized (MapArtClient.class) {
                    pendingImage = file;
                }
            });
            watcher.start();
        });
    }

    /**
     * Duoc goi moi tick tren client thread. Neu co anh moi tu watcher, thong bao
     * cho nguoi choi (khong tu dong build ngay, de tranh build nham khi dang ban viec khac -
     * nguoi choi go /mapart build <ten_file> de bat dau).
     */
    private void checkPendingImage(MinecraftClient client) {
        File img;
        synchronized (MapArtClient.class) {
            img = pendingImage;
            pendingImage = null;
        }
        if (img != null && client.player != null) {
            client.player.sendMessage(
                    Text.literal("[MapArt] Phat hien anh moi: " + img.getName()
                            + ". Go /mapart build " + img.getName() + " <rong> <cao> de xay."),
                    false
            );
        }
    }
}
