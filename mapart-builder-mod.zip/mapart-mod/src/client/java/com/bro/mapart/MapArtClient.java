package com.bro.mapart;

import com.bro.mapart.build.AutoBuilder;
import com.bro.mapart.color.BlockColorEntry;
import com.bro.mapart.color.BlockPaletteBuilder;
import com.bro.mapart.command.MapArtCommand;
import com.bro.mapart.watcher.FolderWatcher;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

import java.io.File;
import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;

public class MapArtClient implements ClientModInitializer {

    public static volatile List<BlockColorEntry> PALETTE;
    public static volatile String PALETTE_ERROR = null;
    public static final AutoBuilder BUILDER = new AutoBuilder();
    public static Path WATCH_FOLDER;
    private static FolderWatcher watcher;
    private static File pendingImage = null;

    private ScheduledExecutorService bgExecutor;

    @Override
    public void onInitializeClient() {
        MapArtMod.LOGGER.info("[MapArt] Khoi tao MapArt Auto Builder...");

        WATCH_FOLDER = FabricLoader.getInstance().getGameDir().resolve("mapart_input");
        MapArtMod.LOGGER.info("[MapArt] Thu muc theo doi anh: {}", WATCH_FOLDER.toAbsolutePath());

        try {
            bgExecutor = Executors.newSingleThreadScheduledExecutor(r -> {
                Thread t = new Thread(r, "MapArt-Background");
                t.setDaemon(true);
                return t;
            });
            MapArtMod.LOGGER.info("[MapArt] Background executor da tao thanh cong.");
        } catch (Throwable t) {
            MapArtMod.LOGGER.error("[MapArt] LOI NGHIEM TRONG: khong the tao background executor.", t);
            PALETTE_ERROR = "Khong the tao background thread: " + t.getMessage();
        }

        ClientTickEvents.END_CLIENT_TICK.register(this::onFirstReadyTick);
        ClientCommandRegistrationCallback.EVENT.register(MapArtCommand::register);
        com.bro.mapart.command.MapArtKeyBindings.register();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (BUILDER.isActive()) {
                BUILDER.tick(client);
            }
            checkPendingImage(client);
        });

        // Khi nguoi choi ngat ket noi (ESC -> Quit to Title, doi server, doi the gioi...),
        // luu progress + reset ve IDLE de khi vao lai khong bi mat quyen dieu khien input.
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) ->
                BUILDER.onDisconnect(client));

        MapArtMod.LOGGER.info("[MapArt] Dang ky xong tat ca event handlers.");
    }

    private boolean initTriggered = false;

    private void onFirstReadyTick(MinecraftClient client) {
        if (initTriggered) return;
        initTriggered = true;

        MapArtMod.LOGGER.info("[MapArt] Tick dau tien nhan duoc, bat dau khoi tao bang mau + watcher.");

        if (bgExecutor == null) {
            MapArtMod.LOGGER.error("[MapArt] bgExecutor la null, khong the chay background task. Chay truc tiep tren client thread thay the (co the giat lag mot chut).");
            runInitTask();
            return;
        }

        try {
            bgExecutor.submit(this::runInitTask);
            MapArtMod.LOGGER.info("[MapArt] Da submit task khoi tao vao background executor.");
        } catch (Throwable t) {
            MapArtMod.LOGGER.error("[MapArt] Khong the submit task vao executor, chay truc tiep thay the.", t);
            runInitTask();
        }
    }

    private void runInitTask() {
        MapArtMod.LOGGER.info("[MapArt] Bat dau xay dung bang mau block...");
        try {
            List<BlockColorEntry> result = BlockPaletteBuilder.buildOrLoadPalette();
            PALETTE = result;
            MapArtMod.LOGGER.info("[MapArt] Bang mau san sang: {} block.", result != null ? result.size() : -1);
        } catch (Throwable e) {
            MapArtMod.LOGGER.error("[MapArt] LOI khi build bang mau block.", e);
            PALETTE_ERROR = e.getClass().getSimpleName() + ": " + e.getMessage();
        }

        try {
            watcher = new FolderWatcher(WATCH_FOLDER, file -> {
                synchronized (MapArtClient.class) {
                    pendingImage = file;
                }
            });
            watcher.start();
            MapArtMod.LOGGER.info("[MapArt] FolderWatcher da khoi dong.");
        } catch (Throwable e) {
            MapArtMod.LOGGER.error("[MapArt] LOI khi khoi dong FolderWatcher.", e);
        }
    }

    private void checkPendingImage(MinecraftClient client) {
        File img;
        synchronized (MapArtClient.class) {
            img = pendingImage;
            pendingImage = null;
        }
        if (img != null && client.player != null) {
            client.player.sendMessage(
                    Text.literal("[MapArt] Phat hien anh moi: " + img.getName()
                            + ". Go /mapart build " + img.getName() + " <rong> <cao> de xay."),
                    false
            );
        }
    }
}
