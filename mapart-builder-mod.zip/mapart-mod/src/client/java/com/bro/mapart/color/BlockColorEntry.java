package com.bro.mapart.color;

import net.minecraft.block.Block;
import net.minecraft.item.Item;

/**
 * Mot block hop le de dung trong map art, kem mau trung binh (RGB) cua no
 * va item tuong ung de dat block (item de lay tu inventory).
 */
public class BlockColorEntry {
    public final Block block;
    public final Item item;
    public final int r;
    public final int g;
    public final int b;

    public BlockColorEntry(Block block, Item item, int r, int g, int b) {
        this.block = block;
        this.item = item;
        this.r = r;
        this.g = g;
        this.b = b;
    }

    /**
     * Khoang cach mau theo khong gian "weighted Euclidean" (gan giong redmean),
     * chinh xac hon Euclidean thuan tuy cho mat nguoi.
     */
    public double distanceTo(int tr, int tg, int tb) {
        double rmean = (this.r + tr) / 2.0;
        double dr = this.r - tr;
        double dg = this.g - tg;
        double db = this.b - tb;
        double weightR = 2.0 + rmean / 256.0;
        double weightG = 4.0;
        double weightB = 2.0 + (255 - rmean) / 256.0;
        return Math.sqrt(weightR * dr * dr + weightG * dg * dg + weightB * db * db);
    }

    @Override
    public String toString() {
        return "BlockColorEntry{" + block + " rgb=(" + r + "," + g + "," + b + ")}";
    }
}
