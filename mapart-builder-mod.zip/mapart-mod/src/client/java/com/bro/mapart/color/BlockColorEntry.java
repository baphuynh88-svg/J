package com.bro.mapart.color;

import net.minecraft.block.Block;
import net.minecraft.item.Item;

/**
 * Mot block hop le de dung trong map art, kem mau trung binh (RGB) cua no
 * va item tuong ung de dat block (item de lay tu inventory).
 *
 * Khoang cach mau tinh trong khong gian CIELAB (Delta E 76, co them trong so
 * cho hue) thay vi RGB: Lab sat voi cam nhan mat nguoi hon nhieu, dac biet voi
 * mau xanh/tim nhu navy - cyan, noi RGB Euclidean/redmean hay chon nham block xam.
 */
public class BlockColorEntry {
    public final Block block;
    public final Item item;
    public final int r;
    public final int g;
    public final int b;

    // Lab da tinh san (tranh tinh lai moi lan so sanh)
    private final double labL;
    private final double labA;
    private final double labB;

    public BlockColorEntry(Block block, Item item, int r, int g, int b) {
        this.block = block;
        this.item = item;
        this.r = r;
        this.g = g;
        this.b = b;
        double[] lab = rgbToLab(r, g, b);
        this.labL = lab[0];
        this.labA = lab[1];
        this.labB = lab[2];
    }

    /**
     * Khoang cach mau trong CIELAB. Thanh phan L (do sang) co trong so nho hon
     * a/b (sac do) de anh giu dung hue khi khong co block du sang/toi.
     * Vi du: navy -> uu tien block xanh dam hon la block xam cung do sang.
     */
    public double distanceTo(int tr, int tg, int tb) {
        double[] t = rgbToLab(tr, tg, tb);
        double dL = this.labL - t[0];
        double dA = this.labA - t[1];
        double dB = this.labB - t[2];
        final double wL = 0.6;
        final double wC = 1.6;
        return Math.sqrt(wL * dL * dL + wC * dA * dA + wC * dB * dB);
    }

    private static double[] rgbToLab(int r, int g, int b) {
        // sRGB -> linear
        double rl = srgbToLinear(r / 255.0);
        double gl = srgbToLinear(g / 255.0);
        double bl = srgbToLinear(b / 255.0);

        // linear RGB -> XYZ (D65)
        double x = rl * 0.4124564 + gl * 0.3575761 + bl * 0.1804375;
        double y = rl * 0.2126729 + gl * 0.7151522 + bl * 0.0721750;
        double z = rl * 0.0193339 + gl * 0.1191920 + bl * 0.9503041;

        // Normalize theo white point D65
        double fx = labF(x / 0.95047);
        double fy = labF(y / 1.00000);
        double fz = labF(z / 1.08883);

        return new double[]{116.0 * fy - 16.0, 500.0 * (fx - fy), 200.0 * (fy - fz)};
    }

    private static double srgbToLinear(double c) {
        return c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
    }

    private static double labF(double t) {
        return t > 0.008856 ? Math.cbrt(t) : (7.787 * t + 16.0 / 116.0);
    }

    @Override
    public String toString() {
        return "BlockColorEntry{" + block + " rgb=(" + r + "," + g + "," + b + ")}";
    }
}
