package com.bro.mapart.command;

import com.bro.mapart.MapArtClient;
import com.bro.mapart.MapArtMod;
import com.bro.mapart.build.BuildProgress;
import com.bro.mapart.image.ImageConverter;
import com.bro.mapart.image.MapArtGrid;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.client.MinecraftClient;
import net.minecraft.command.CommandRegistryAccess;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.io.File;
import java.util.List;
import java.util.Map;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.argument;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

public class MapArtCommand {

    public static void register(CommandDispatcher<FabricClientCommandSource> dispatcher,
                                 CommandRegistryAccess registryAccess) {
        dispatcher.register(literal("mapart")
                .then(literal("build")
                        .then(argument("filename", StringArgumentType.string())
                                .then(argument("width", IntegerArgumentType.integer(1, 4096))
                                        .then(argument("height", IntegerArgumentType.integer(1, 4096))
                                                .executes(MapArtCommand::runBuild)))))
                .then(literal("confirm").executes(MapArtCommand::runConfirm))
                .then(literal("resume").executes(MapArtCommand::runResume))
                .then(literal("stop").executes(MapArtCommand::runStop))
                .then(literal("status").executes(MapArtCommand::runStatus))
                .then(literal("list").executes(MapArtCommand::runList))
        );
    }

    private static int runBuild(CommandContext<FabricClientCommandSource> ctx) {
        String filename = StringArgumentType.getString(ctx, "filename");
        int width = IntegerArgumentType.getInteger(ctx, "width");
        int height = IntegerArgumentType.getInteger(ctx, "height");

        FabricClientCommandSource source = ctx.getSource();
        MinecraftClient client = MinecraftClient.getInstance();

        if (MapArtClient.PALETTE == null || MapArtClient.PALETTE.isEmpty()) {
            String errMsg = MapArtClient.PALETTE_ERROR;
            if (errMsg != null) {
                source.sendFeedback(Text.literal("[MapArt] Bang mau bi LOI khi khoi tao: " + errMsg + ". Xem logs/latest.log de biet chi tiet."));
            } else {
                source.sendFeedback(Text.literal("[MapArt] Bang mau chua san sang, doi vai giay roi thu lai."));
            }
            return 0;
        }

        File imageFile = MapArtClient.WATCH_FOLDER.resolve(filename).toFile();
        if (!imageFile.exists()) {
            source.sendFeedback(Text.literal("[MapArt] Khong tim thay file: " + imageFile.getAbsolutePath()));
            return 0;
        }

        try {
            MapArtGrid grid = ImageConverter.convert(imageFile, width, height, MapArtClient.PALETTE);
            source.sendFeedback(Text.literal("[MapArt] Da convert anh (" + width + "x" + height + "). Bat dau chuan bi khu vuc..."));
            MapArtClient.BUILDER.startNew(client, grid, imageFile.getAbsolutePath());
        } catch (ImageConverter.ConversionException e) {
            source.sendFeedback(Text.literal("[MapArt] Loi: " + e.getMessage()));
        }

        return 1;
    }

    private static int runConfirm(CommandContext<FabricClientCommandSource> ctx) {
        MinecraftClient client = MinecraftClient.getInstance();
        MapArtClient.BUILDER.confirmAreaReady(client);
        return 1;
    }

    private static int runResume(CommandContext<FabricClientCommandSource> ctx) {
        FabricClientCommandSource source = ctx.getSource();
        MinecraftClient client = MinecraftClient.getInstance();

        BuildProgress progress = BuildProgress.load();
        if (progress == null) {
            source.sendFeedback(Text.literal("[MapArt] Khong co tien do nao de tiep tuc."));
            return 0;
        }
        if (MapArtClient.PALETTE == null || MapArtClient.PALETTE.isEmpty()) {
            String errMsg = MapArtClient.PALETTE_ERROR;
            if (errMsg != null) {
                source.sendFeedback(Text.literal("[MapArt] Bang mau bi LOI khi khoi tao: " + errMsg + ". Xem logs/latest.log de biet chi tiet."));
            } else {
                source.sendFeedback(Text.literal("[MapArt] Bang mau chua san sang, doi vai giay roi thu lai."));
            }
            return 0;
        }

        File imageFile = new File(progress.sourceImagePath);
        if (!imageFile.exists()) {
            source.sendFeedback(Text.literal("[MapArt] Khong tim thay lai file anh goc: " + progress.sourceImagePath));
            return 0;
        }

        try {
            MapArtGrid grid = ImageConverter.convert(imageFile, progress.width, progress.depth, MapArtClient.PALETTE);
            MapArtClient.BUILDER.resume(client, grid, progress);
        } catch (ImageConverter.ConversionException e) {
            source.sendFeedback(Text.literal("[MapArt] Loi doc lai anh: " + e.getMessage()));
        }
        return 1;
    }

    private static int runStop(CommandContext<FabricClientCommandSource> ctx) {
        MinecraftClient client = MinecraftClient.getInstance();
        MapArtClient.BUILDER.stop(client);
        return 1;
    }

    private static int runStatus(CommandContext<FabricClientCommandSource> ctx) {
        ctx.getSource().sendFeedback(Text.literal("[MapArt] " + MapArtClient.BUILDER.getStatusText()));
        return 1;
    }

    /**
     * Liet ke toan bo cac loai item can co de xay xong toan bo map art,
     * kem so luong o su dung va so stack (64/stack) tuong ung. Giup nguoi
     * choi chuan bi truoc hotbar/inventory thay vi phai doan mo hoac dung
     * lai giua chung nhieu lan de kiem tung item mot.
     */
    private static int runList(CommandContext<FabricClientCommandSource> ctx) {
        FabricClientCommandSource source = ctx.getSource();
        MapArtGrid grid = MapArtClient.BUILDER.getGrid();

        if (grid == null) {
            source.sendFeedback(Text.literal("[MapArt] Chua co anh nao duoc convert. Go /mapart build truoc."));
            return 0;
        }

        Map<Item, Integer> required = grid.summarizeRequiredItems();
        if (required.isEmpty()) {
            source.sendFeedback(Text.literal("[MapArt] Anh nay khong can block nao (toan bo trong suot?)."));
            return 0;
        }

        int totalTypes = required.size();
        int totalCells = required.values().stream().mapToInt(Integer::intValue).sum();

        source.sendFeedback(Text.literal("[MapArt] === Danh sach block can (" + totalTypes + " loai, " + totalCells + " o) ==="));

        int shown = 0;
        int maxShow = 40; // gioi han so dong hien thi de tranh spam chat qua dai
        for (Map.Entry<Item, Integer> e : required.entrySet()) {
            if (shown >= maxShow) break;
            int count = e.getValue();
            int stacks = (count + 63) / 64;
            String itemName = e.getKey().getName().getString();
            Identifier itemId = Registries.ITEM.getId(e.getKey());
            source.sendFeedback(Text.literal(
                    String.format("  - %s (%s): %d o (~%d stack)", itemName, itemId, count, stacks)
            ));
            shown++;
        }

        if (totalTypes > maxShow) {
            source.sendFeedback(Text.literal("  ... va " + (totalTypes - maxShow) + " loai khac (bi cat bot de tranh spam chat)."));
        }

        return 1;
    }
}
