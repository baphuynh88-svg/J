package com.bro.mapart.command;

import com.bro.mapart.gui.MapArtScreen;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

/**
 * Phim tat M: mo/dong MapArtScreen (GUI danh sach block).
 * Nguoi choi co the doi phim khac trong Options > Controls > Key Binds.
 */
public class MapArtKeyBindings {

    private static KeyBinding showListKey;

    public static void register() {
        KeyBinding.Category category = KeyBinding.Category.create(
                Identifier.of("mapart-builder", "main")
        );

        showListKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.mapart-builder.show_list",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_M,
                category
        ));

        ClientTickEvents.END_CLIENT_TICK.register(MapArtKeyBindings::onTick);
    }

    private static void onTick(MinecraftClient client) {
        while (showListKey.wasPressed()) {
            if (client.currentScreen instanceof MapArtScreen) {
                // Dang mo -> dong
                client.setScreen(null);
            } else if (client.currentScreen == null) {
                // Dang choi binh thuong -> mo GUI
                client.setScreen(new MapArtScreen());
            }
            // Neu dang mo screen khac (e.g. inventory) thi bam M khong lam gi
        }
    }
}
