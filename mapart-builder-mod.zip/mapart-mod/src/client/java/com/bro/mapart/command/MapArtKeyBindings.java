package com.bro.mapart.command;

import com.bro.mapart.MapArtClient;
import com.bro.mapart.image.MapArtGrid;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.Map;

/**
 * Phim tat M: sau khi convert anh xong (/mapart build), bam M bat cu luc
 * nao de xem lai danh sach block/item can chuan bi, khong can go lenh
 * /mapart list bang tay. Dang ky qua KeyBindingHelper nen nguoi choi co
 * the doi phim khac trong Options > Controls > Key Binds neu muon.
 */
public class MapArtKeyBindings {

    private static KeyBinding showListKey;

    public static void register() {
        // 1.21.11: KeyBinding nhan KeyBinding.Category (khong con nhan String nhu ban cu).
        // Ten hien thi trong Options > Controls lay tu key: key.category.<namespace>.<path>
        // = "key.category.mapart-builder.main" (khai bao trong lang file, neu khong co se hien key tho).
        KeyBinding.Category category = KeyBinding.Category.create(Identifier.of("mapart-builder", "main"));

        showListKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.mapart-builder.show_list",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_M,
                category
        ));

        net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (showListKey.wasPressed()) {
                printRequiredList(client);
            }
        });
    }

    private static void printRequiredList(net.minecraft.client.MinecraftClient client) {
        if (client.player == null) return;

        MapArtGrid grid = MapArtClient.BUILDER.getGrid();
        if (grid == null) {
            client.player.sendMessage(Text.literal("[MapArt] Chua co anh nao duoc convert. Go /mapart build truoc."), false);
            return;
        }

        Map<Item, Integer> required = grid.summarizeRequiredItems();
        if (required.isEmpty()) {
            client.player.sendMessage(Text.literal("[MapArt] Anh nay khong can block nao."), false);
            return;
        }

        int totalTypes = required.size();
        int totalCells = required.values().stream().mapToInt(Integer::intValue).sum();

        client.player.sendMessage(Text.literal("[MapArt] === Danh sach block can (" + totalTypes + " loai, " + totalCells + " o) ==="), false);

        int shown = 0;
        int maxShow = 40;
        for (Map.Entry<Item, Integer> e : required.entrySet()) {
            if (shown >= maxShow) break;
            int count = e.getValue();
            int stacks = (count + 63) / 64;
            String itemName = e.getKey().getName().getString();
            Identifier itemId = Registries.ITEM.getId(e.getKey());
            client.player.sendMessage(Text.literal(
                    String.format("  - %s (%s): %d o (~%d stack)", itemName, itemId, count, stacks)
            ), false);
            shown++;
        }

        if (totalTypes > maxShow) {
            client.player.sendMessage(Text.literal("  ... va " + (totalTypes - maxShow) + " loai khac."), false);
        }
    }
}
