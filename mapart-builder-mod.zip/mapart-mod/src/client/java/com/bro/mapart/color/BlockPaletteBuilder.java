package com.bro.mapart.color;

import com.bro.mapart.MapArtMod;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.Block;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.resource.Resource;
import net.minecraft.util.Identifier;

import java.io.*;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/**
 * Quet toan bo block registry, loc block hop le de lam map art (block co
 * item tuong ung, khong trong suot, khong co model dac biet nhu thang/cua),
 * doc texture PNG cua block, tinh mau trung binh (bo qua pixel alpha=0),
 * roi build thanh bang mau. Ket qua duoc cache ra file JSON de khong phai
 * tinh lai moi lan khoi dong.
 */
public class BlockPaletteBuilder {

    // v3: loai snow layer (snow), powder_snow, va moi block khong phai BlockItem.
    //     Doi ten file de tu dong rebuild palette, khong can xoa tay.
    private static final String CACHE_FILE_NAME = "mapart_palette_cache_v3.json";

    /**
     * Danh sach id texture path (khong bao gom "block/" prefix) can bo qua
     * vi khong phai la block "phang mau deu" phu hop lam pixel art:
     * cay coi, thang, cua, day leo, duong ray, biner, v.v.
     * Day la danh sach loc theo TEN BLOCK (registry id), khong phai class,
     * vi nhieu block co the trung texture nhung khac hanh vi.
     */
    private static final Set<String> BLACKLIST_KEYWORDS = new java.util.HashSet<>(java.util.Arrays.asList(
            "door", "trapdoor", "ladder", "rail", "torch", "lantern",
            "fence", "wall", "slab", "stairs", "button", "pressure_plate",
            "sign", "banner", "carpet", "bed", "chest", "barrel",
            "furnace", "anvil", "cauldron", "flower_pot", "skull",
            "head", "candle", "lily_pad", "vine", "sapling", "sugar_cane",
            "bamboo", "kelp", "seagrass", "coral_fan", "chain", "lever",
            "tripwire", "scaffolding", "cake", "bell", "campfire", "web",
            "portal", "spawner", "barrier", "light", "structure_void",
            "command_block", "jigsaw", "piston", "observer", "dispenser",
            "dropper", "hopper", "comparator", "repeater",
            "redstone_wire", "daylight_detector", "glass_pane", "iron_bars",
            "conduit", "end_rod", "lightning_rod", "pointed_dripstone",
            "amethyst_cluster", "amethyst_bud", "turtle_egg", "sculk_sensor",
            "sculk_shrieker", "sculk_vein", "hanging_roots", "cave_vines",
            "twisting_vines", "weeping_vines", "flower", "sprout",
            "leaf_litter", "bush", "podzol_sapling",
            // --- them: block texture lon xon / nhieu chi tiet, ra hinh nhieu ---
            "_ore", "ore_", "leaves", "grass_block", "mycelium", "podzol",
            "glass", "ice", "tnt", "bookshelf", "crafting_table", "loom",
            "smoker", "blast_furnace", "fletching", "cartography", "smithing",
            "lectern", "composter", "beehive", "bee_nest", "target",
            "jukebox", "note_block", "respawn_anchor", "lodestone",
            "sponge", "hay_block", "melon", "pumpkin", "cactus",
            "dried_kelp", "frogspawn", "moss_carpet", "snow_layer",
            "infested", "budding", "crying_obsidian", "reinforced",
            "trial_spawner", "vault", "crafter", "copper_bulb",
            "creaking", "heavy_core", "decorated_pot", "suspicious",
            "bedrock", "end_portal", "end_gateway", "sniffer_egg",
            "dragon_egg", "shulker", "cocoa", "farmland", "dirt_path",
            "magma", "sea_lantern", "glowstone", "shroomlight", "froglight",
            "beacon", "enchanting", "brewing", "grindstone", "stonecutter",
            "water", "lava", "fire", "command", "test_", "spore_blossom"
    ));

    /**
     * Block co path khop CHINH XAC (khong phai contains) thi bi loai, du khong khop keyword nao.
     * Dung cho cac truong hop ten ngan, neu them vao BLACKLIST_KEYWORDS se lo block khac:
     *  - "snow"        : snow layer (item la snow, nhung chi dat duoc theo tang, khong phu hop map art flat)
     *  - "powder_snow" : item la powder_snow_bucket (BucketItem, khong phai BlockItem => interactBlock
     *                    khong hoat dong nhu dat block binh thuong, gay spam dat 1 chỗ).
     */
    private static final java.util.Set<String> BLACKLIST_EXACT = new java.util.HashSet<>(java.util.Arrays.asList(
            "snow",         // snow layer - ko phai solid block, tu sinh ra o biome tuyet
            "powder_snow"   // xo tuyet bot - item la BucketItem, khong the dat qua interactBlock
    ));

    /** Nguong lech chuan mau toi da cua texture (0-255). Cao hon = nhieu block "lon xon" bi loai. */
    private static final double MAX_TEXTURE_STDDEV = 28.0;

    public static class PaletteCacheEntry {
        public String blockId;
        public String itemId;
        public int r, g, b;
    }

    /**
     * Xay bang mau. Neu co cache hop le (cung version mod) thi doc tu cache,
     * neu khong thi quet lai tu texture va ghi cache moi.
     */
    public static List<BlockColorEntry> buildOrLoadPalette() {
        Path cacheDir = FabricLoader.getInstance().getGameDir().resolve("mapart_data");
        Path cacheFile = cacheDir.resolve(CACHE_FILE_NAME);

        List<BlockColorEntry> raw = tryLoadCache(cacheFile);
        if (raw != null && !raw.isEmpty()) {
            MapArtMod.LOGGER.info("[MapArt] Loaded {} block colors from cache.", raw.size());
        } else {
            MapArtMod.LOGGER.info("[MapArt] Building block color palette from textures (first run, may take a moment)...");
            raw = scanAndBuild();
            saveCache(cacheFile, raw);
            MapArtMod.LOGGER.info("[MapArt] Palette built: {} usable blocks.", raw.size());
        }

        // block_config.json duoc ap dung SAU cache => sua file config chi can restart game, khong can xoa cache.
        List<BlockColorEntry> filtered = applyBlockConfig(cacheDir, raw);
        MapArtMod.LOGGER.info("[MapArt] Sau khi ap dung block_config: {} block.", filtered.size());
        return filtered;
    }

    /**
     * File mapart_data/block_config.json (tu tao lan dau, co huong dan ben trong):
     * {
     *   "only": [],                 // neu KHONG rong: CHI dung dung nhung block nay (vd: ["lapis_block","diamond_block"])
     *   "exclude": ["blue_terracotta"],  // loai bo block cu the
     *   "excludeKeywords": ["terracotta"], // loai bo moi block co ten chua tu khoa
     *   "overrides": { "blue_terracotta": [10, 30, 70] } // ep mau RGB cho block (chinh tay khi texture lech)
     * }
     * Ten block viet KHONG co "minecraft:".
     */
    public static class BlockConfig {
        public List<String> only = new ArrayList<>();
        public List<String> exclude = new ArrayList<>();
        public List<String> excludeKeywords = new ArrayList<>();
        public Map<String, int[]> overrides = new LinkedHashMap<>();
    }

    private static List<BlockColorEntry> applyBlockConfig(Path dir, List<BlockColorEntry> raw) {
        Path cfgFile = dir.resolve("block_config.json");
        BlockConfig cfg = null;
        try {
            if (!Files.exists(cfgFile)) {
                Files.createDirectories(dir);
                BlockConfig template = new BlockConfig();
                template.exclude.add("example_block_to_exclude");
                template.excludeKeywords.add("example_keyword");
                template.overrides.put("example_block", new int[]{255, 255, 255});
                try (Writer w = Files.newBufferedWriter(cfgFile)) {
                    new GsonBuilder().setPrettyPrinting().create().toJson(template, w);
                }
                MapArtMod.LOGGER.info("[MapArt] Da tao block_config.json mau tai {}", cfgFile);
                return raw;
            }
            try (Reader r = Files.newBufferedReader(cfgFile)) {
                cfg = new Gson().fromJson(r, BlockConfig.class);
            }
        } catch (Exception e) {
            MapArtMod.LOGGER.warn("[MapArt] Khong doc duoc block_config.json, bo qua.", e);
            return raw;
        }
        if (cfg == null) return raw;

        List<BlockColorEntry> out = new ArrayList<>();
        for (BlockColorEntry c : raw) {
            Identifier id = Registries.BLOCK.getId(c.block);
            if (id == null) continue;
            String path = id.getPath();

            if (cfg.only != null && !cfg.only.isEmpty() && !cfg.only.contains(path)) continue;
            if (cfg.exclude != null && cfg.exclude.contains(path)) continue;
            boolean kwHit = false;
            if (cfg.excludeKeywords != null) {
                for (String kw : cfg.excludeKeywords) {
                    if (kw != null && !kw.isEmpty() && path.contains(kw)) { kwHit = true; break; }
                }
            }
            if (kwHit) continue;

            int[] ov = cfg.overrides != null ? cfg.overrides.get(path) : null;
            if (ov != null && ov.length == 3) {
                out.add(new BlockColorEntry(c.block, c.item, ov[0], ov[1], ov[2]));
            } else {
                out.add(c);
            }
        }
        // Neu config loai het sach thi khong the xay -> giu nguyen raw de khoi hong
        if (out.isEmpty()) {
            MapArtMod.LOGGER.warn("[MapArt] block_config loai bo het block! Bo qua config.");
            return raw;
        }
        return out;
    }

    private static boolean isBlacklisted(String path) {
        if (BLACKLIST_EXACT.contains(path)) return true;
        for (String kw : BLACKLIST_KEYWORDS) {
            if (path.contains(kw)) return true;
        }
        return false;
    }

    private static List<BlockColorEntry> scanAndBuild() {
        List<BlockColorEntry> result = new ArrayList<>();
        MinecraftClient client = MinecraftClient.getInstance();

        for (Block block : Registries.BLOCK) {
            Identifier id = Registries.BLOCK.getId(block);
            if (id == null) continue;
            String path = id.getPath();
            if (isBlacklisted(path)) continue;

            Item item = block.asItem();
            if (item == null || item == net.minecraft.item.Items.AIR) continue;

            // Chi giu block co BlockItem tuong ung (dat duoc bang right-click thong thuong).
            // BucketItem (powder_snow_bucket), SpawnEggItem, ... bi loai o day.
            if (!(item instanceof net.minecraft.item.BlockItem)) continue;

            Identifier texId = Identifier.of(id.getNamespace(), "textures/block/" + path + ".png");
            int[] rgb = readAverageColor(client, texId);
            if (rgb == null) continue; // khong doc duoc texture (item khong co block texture chuan)

            // Bo qua block gan nhu hoan toan trong suot (texture rong / toan alpha thap)
            result.add(new BlockColorEntry(block, item, rgb[0], rgb[1], rgb[2]));
        }

        return result;
    }

    /**
     * Doc texture PNG cua block qua resource manager, tinh mau trung binh
     * (bo qua pixel co alpha thap). Tra ve null neu khong tim thay texture.
     */
    private static int[] readAverageColor(MinecraftClient client, Identifier texId) {
        Optional<Resource> resOpt = client.getResourceManager().getResource(texId);
        if (resOpt.isEmpty()) return null;

        try (InputStream stream = resOpt.get().getInputStream()) {
            byte[] data = stream.readAllBytes();
            try (NativeImage img = NativeImage.read(data)) {
                int w = img.getWidth();
                int h = img.getHeight();
                // Texture animated (nhieu frame xep doc): chi lay frame dau (hinh vuong tren cung)
                int sampleH = Math.min(h, w);

                long sumR = 0, sumG = 0, sumB = 0;
                long count = 0;
                long total = 0;
                for (int y = 0; y < sampleH; y++) {
                    for (int x = 0; x < w; x++) {
                        total++;
                        // 1.21.11: getColorArgb tra ve ARGB chuan (A<<24 | R<<16 | G<<8 | B).
                        // (Ban cu doc theo ABGR nen bi dao kenh R<->B => cyan thanh vang, navy thanh nau.)
                        int argb = img.getColorArgb(x, y);
                        int alpha = (argb >>> 24) & 0xFF;
                        if (alpha < 128) continue; // bo qua pixel trong suot / gan trong suot
                        sumR += (argb >> 16) & 0xFF;
                        sumG += (argb >> 8) & 0xFF;
                        sumB += argb & 0xFF;
                        count++;
                    }
                }
                if (count == 0) return null;
                // Texture co qua nhieu pixel trong suot (>30%) thi khong phai block dac -> bo
                if (count < total * 0.7) return null;

                int avgR = (int) (sumR / count);
                int avgG = (int) (sumG / count);
                int avgB = (int) (sumB / count);

                // Do "nhieu" cua texture: lech chuan mau so voi trung binh.
                // Block qua lon xon (ore, gravel, ...) nhin tu tren xuong ra hinh nhieu
                // => bo. Block phang mau (wool, concrete, terracotta, planks, ...) giu lai.
                double var = 0;
                for (int y = 0; y < sampleH; y++) {
                    for (int x = 0; x < w; x++) {
                        int argb = img.getColorArgb(x, y);
                        if (((argb >>> 24) & 0xFF) < 128) continue;
                        double dr = ((argb >> 16) & 0xFF) - avgR;
                        double dg = ((argb >> 8) & 0xFF) - avgG;
                        double db = (argb & 0xFF) - avgB;
                        var += dr * dr + dg * dg + db * db;
                    }
                }
                double stdDev = Math.sqrt(var / (count * 3.0));
                if (stdDev > MAX_TEXTURE_STDDEV) return null;

                return new int[]{avgR, avgG, avgB};
            }
        } catch (IOException e) {
            return null;
        }
    }

    private static List<BlockColorEntry> tryLoadCache(Path cacheFile) {
        if (!Files.exists(cacheFile)) return null;
        try (Reader reader = Files.newBufferedReader(cacheFile)) {
            Gson gson = new Gson();
            Type listType = new TypeToken<List<PaletteCacheEntry>>() {}.getType();
            List<PaletteCacheEntry> entries = gson.fromJson(reader, listType);
            if (entries == null) return null;

            List<BlockColorEntry> out = new ArrayList<>();
            for (PaletteCacheEntry e : entries) {
                Identifier blockId = Identifier.tryParse(e.blockId);
                if (blockId == null) continue;
                Block block = Registries.BLOCK.get(blockId);
                Item item = block.asItem();
                if (item == null || item == net.minecraft.item.Items.AIR) continue;
                out.add(new BlockColorEntry(block, item, e.r, e.g, e.b));
            }
            return out;
        } catch (Exception e) {
            MapArtMod.LOGGER.warn("[MapArt] Failed to load palette cache, will rebuild.", e);
            return null;
        }
    }

    private static void saveCache(Path cacheFile, List<BlockColorEntry> palette) {
        try {
            Files.createDirectories(cacheFile.getParent());
            List<PaletteCacheEntry> entries = new ArrayList<>();
            for (BlockColorEntry c : palette) {
                Identifier blockId = Registries.BLOCK.getId(c.block);
                if (blockId == null) continue;
                PaletteCacheEntry e = new PaletteCacheEntry();
                e.blockId = blockId.toString();
                e.itemId = Registries.ITEM.getId(c.item).toString();
                e.r = c.r;
                e.g = c.g;
                e.b = c.b;
                entries.add(e);
            }
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            try (Writer writer = Files.newBufferedWriter(cacheFile)) {
                gson.toJson(entries, writer);
            }
        } catch (IOException e) {
            MapArtMod.LOGGER.warn("[MapArt] Failed to save palette cache.", e);
        }
    }

    /**
     * Tim block gan mau nhat trong bang mau cho 1 pixel RGB cho truoc.
     */
    public static BlockColorEntry findClosest(List<BlockColorEntry> palette, int r, int g, int b) {
        BlockColorEntry best = null;
        double bestDist = Double.MAX_VALUE;
        for (BlockColorEntry c : palette) {
            double d = c.distanceTo(r, g, b);
            if (d < bestDist) {
                bestDist = d;
                best = c;
            }
        }
        return best;
    }
}
