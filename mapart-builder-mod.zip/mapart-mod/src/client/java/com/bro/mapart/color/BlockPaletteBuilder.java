package com.bro.mapart.color;

import com.bro.mapart.MapArtMod;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.Block;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.resource.Resource;
import net.minecraft.util.Identifier;

import java.io.*;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/**
 * Quet toan bo block registry, loc block hop le de lam map art (block co
 * item tuong ung, khong trong suot, khong co model dac biet nhu thang/cua),
 * doc texture PNG cua block, tinh mau trung binh (bo qua pixel alpha=0),
 * roi build thanh bang mau. Ket qua duoc cache ra file JSON de khong phai
 * tinh lai moi lan khoi dong.
 */
public class BlockPaletteBuilder {

    private static final String CACHE_FILE_NAME = "mapart_palette_cache.json";

    /**
     * Danh sach id texture path (khong bao gom "block/" prefix) can bo qua
     * vi khong phai la block "phang mau deu" phu hop lam pixel art:
     * cay coi, thang, cua, day leo, duong ray, biner, v.v.
     * Day la danh sach loc theo TEN BLOCK (registry id), khong phai class,
     * vi nhieu block co the trung texture nhung khac hanh vi.
     */
    private static final Set<String> BLACKLIST_KEYWORDS = new java.util.HashSet<>(java.util.Arrays.asList(
            "door", "trapdoor", "ladder", "rail", "torch", "lantern",
            "fence", "wall", "slab", "stairs", "button", "pressure_plate",
            "sign", "banner", "carpet", "bed", "chest", "barrel",
            "furnace", "anvil", "cauldron", "flower_pot", "skull",
            "head", "candle", "lily_pad", "vine", "sapling", "sugar_cane",
            "bamboo", "kelp", "seagrass", "coral_fan", "chain", "lever",
            "tripwire", "scaffolding", "cake", "bell", "campfire", "web",
            "portal", "spawner", "barrier", "light", "structure_void",
            "command_block", "jigsaw", "piston", "observer", "dispenser",
            "dropper", "hopper", "comparator", "repeater",
            "redstone_wire", "daylight_detector", "glass_pane", "iron_bars",
            "conduit", "end_rod", "lightning_rod", "pointed_dripstone",
            "amethyst_cluster", "amethyst_bud", "turtle_egg", "sculk_sensor",
            "sculk_shrieker", "sculk_vein", "hanging_roots", "cave_vines",
            "twisting_vines", "weeping_vines", "flower", "sprout",
            "leaf_litter", "bush", "podzol_sapling"
    ));

    public static class PaletteCacheEntry {
        public String blockId;
        public String itemId;
        public int r, g, b;
    }

    /**
     * Xay bang mau. Neu co cache hop le (cung version mod) thi doc tu cache,
     * neu khong thi quet lai tu texture va ghi cache moi.
     */
    public static List<BlockColorEntry> buildOrLoadPalette() {
        Path cacheDir = FabricLoader.getInstance().getGameDir().resolve("mapart_data");
        Path cacheFile = cacheDir.resolve(CACHE_FILE_NAME);

        List<BlockColorEntry> fromCache = tryLoadCache(cacheFile);
        if (fromCache != null && !fromCache.isEmpty()) {
            MapArtMod.LOGGER.info("[MapArt] Loaded {} block colors from cache.", fromCache.size());
            return fromCache;
        }

        MapArtMod.LOGGER.info("[MapArt] Building block color palette from textures (first run, may take a moment)...");
        List<BlockColorEntry> built = scanAndBuild();
        saveCache(cacheFile, built);
        MapArtMod.LOGGER.info("[MapArt] Palette built: {} usable blocks.", built.size());
        return built;
    }

    private static boolean isBlacklisted(String path) {
        for (String kw : BLACKLIST_KEYWORDS) {
            if (path.contains(kw)) return true;
        }
        return false;
    }

    private static List<BlockColorEntry> scanAndBuild() {
        List<BlockColorEntry> result = new ArrayList<>();
        MinecraftClient client = MinecraftClient.getInstance();

        for (Block block : Registries.BLOCK) {
            Identifier id = Registries.BLOCK.getId(block);
            if (id == null) continue;
            String path = id.getPath();
            if (isBlacklisted(path)) continue;

            Item item = block.asItem();
            if (item == null || item == net.minecraft.item.Items.AIR) continue;

            Identifier texId = Identifier.of(id.getNamespace(), "textures/block/" + path + ".png");
            int[] rgb = readAverageColor(client, texId);
            if (rgb == null) continue; // khong doc duoc texture (item khong co block texture chuan)

            // Bo qua block gan nhu hoan toan trong suot (texture rong / toan alpha thap)
            result.add(new BlockColorEntry(block, item, rgb[0], rgb[1], rgb[2]));
        }

        return result;
    }

    /**
     * Doc texture PNG cua block qua resource manager, tinh mau trung binh
     * (bo qua pixel co alpha thap). Tra ve null neu khong tim thay texture.
     */
    private static int[] readAverageColor(MinecraftClient client, Identifier texId) {
        Optional<Resource> resOpt = client.getResourceManager().getResource(texId);
        if (resOpt.isEmpty()) return null;

        try (InputStream stream = resOpt.get().getInputStream()) {
            byte[] data = stream.readAllBytes();
            try (NativeImage img = NativeImage.read(data)) {
                long sumR = 0, sumG = 0, sumB = 0;
                long count = 0;
                int w = img.getWidth();
                int h = img.getHeight();
                // Neu la texture animated (nhieu frame xep doc), chi lay frame dau (hinh vuong tren cung)
                int sampleH = Math.min(h, w);
                for (int y = 0; y < sampleH; y++) {
                    for (int x = 0; x < w; x++) {
                        int argb = img.getColorArgb(x, y);
                        int alpha = (argb >> 24) & 0xFF;
                        if (alpha < 128) continue; // bo qua pixel trong suot / gan trong suot
                        int r = argb & 0xFF;
                        int g = (argb >> 8) & 0xFF;
                        int b = (argb >> 16) & 0xFF;
                        sumR += r;
                        sumG += g;
                        sumB += b;
                        count++;
                    }
                }
                if (count == 0) return null;
                return new int[]{(int) (sumR / count), (int) (sumG / count), (int) (sumB / count)};
            }
        } catch (IOException e) {
            return null;
        }
    }

    private static List<BlockColorEntry> tryLoadCache(Path cacheFile) {
        if (!Files.exists(cacheFile)) return null;
        try (Reader reader = Files.newBufferedReader(cacheFile)) {
            Gson gson = new Gson();
            Type listType = new TypeToken<List<PaletteCacheEntry>>() {}.getType();
            List<PaletteCacheEntry> entries = gson.fromJson(reader, listType);
            if (entries == null) return null;

            List<BlockColorEntry> out = new ArrayList<>();
            for (PaletteCacheEntry e : entries) {
                Identifier blockId = Identifier.tryParse(e.blockId);
                if (blockId == null) continue;
                Block block = Registries.BLOCK.get(blockId);
                Item item = block.asItem();
                if (item == null || item == net.minecraft.item.Items.AIR) continue;
                out.add(new BlockColorEntry(block, item, e.r, e.g, e.b));
            }
            return out;
        } catch (Exception e) {
            MapArtMod.LOGGER.warn("[MapArt] Failed to load palette cache, will rebuild.", e);
            return null;
        }
    }

    private static void saveCache(Path cacheFile, List<BlockColorEntry> palette) {
        try {
            Files.createDirectories(cacheFile.getParent());
            List<PaletteCacheEntry> entries = new ArrayList<>();
            for (BlockColorEntry c : palette) {
                Identifier blockId = Registries.BLOCK.getId(c.block);
                if (blockId == null) continue;
                PaletteCacheEntry e = new PaletteCacheEntry();
                e.blockId = blockId.toString();
                e.itemId = Registries.ITEM.getId(c.item).toString();
                e.r = c.r;
                e.g = c.g;
                e.b = c.b;
                entries.add(e);
            }
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            try (Writer writer = Files.newBufferedWriter(cacheFile)) {
                gson.toJson(entries, writer);
            }
        } catch (IOException e) {
            MapArtMod.LOGGER.warn("[MapArt] Failed to save palette cache.", e);
        }
    }

    /**
     * Tim block gan mau nhat trong bang mau cho 1 pixel RGB cho truoc.
     */
    public static BlockColorEntry findClosest(List<BlockColorEntry> palette, int r, int g, int b) {
        BlockColorEntry best = null;
        double bestDist = Double.MAX_VALUE;
        for (BlockColorEntry c : palette) {
            double d = c.distanceTo(r, g, b);
            if (d < bestDist) {
                bestDist = d;
                best = c;
            }
        }
        return best;
    }
}
