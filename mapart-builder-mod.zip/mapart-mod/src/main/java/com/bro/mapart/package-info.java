/**
 * Mod nay hoan toan client-side. Main source set khong chua logic,
 * chi ton tai de thoa man cau truc splitEnvironmentSourceSets() cua Loom
 * (fabric.mod.json nam trong src/main/resources).
 */
package com.bro.mapart;
