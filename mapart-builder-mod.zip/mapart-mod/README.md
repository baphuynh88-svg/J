# MapArt Auto Builder

Mod Fabric (client-only) cho Minecraft 1.21.11: tu dong chuyen anh thanh
map art top-down (nhin tu tren xuong) va tu xay bang nhan vat that
(di chuyen + dat block giong nguoi choi, khong teleport, khong spam packet).

## Cach hoat dong

1. Bo anh (.png/.jpg/...) vao thu muc `mapart_input/` trong thu muc game
   (`.minecraft/mapart_input/`). Mod se tu tao thu muc nay neu chua co.
2. Vao game, mod se bao trong chat khi phat hien anh moi.
3. Go lenh:
   ```
   /mapart build <ten_file_anh> <rong> <cao>
   ```
   Vi du: `/mapart build house.png 64 64`
4. Mod se san phang khu vuc (tai vi tri dang dung), ve vien bang glass de
   danh dau ranh gioi. Ban tu don cay/vat can con sot (neu co bao) roi go:
   ```
   /mapart confirm
   ```
5. Mod bat dau tu dong xay: di chuyen + dat block theo tung hang.
   - Che do Creative: tu dong lay block can dung.
   - Che do Survival: kiem tra inventory, neu thieu se dung lai va bao
     chinh xac ten + so luong item con thieu trong chat.
6. Neu bi dung lai (thieu item, thoat game, crash...), bo sung item roi go:
   ```
   /mapart resume
   ```
7. Xem tien do bat cu luc nao:
   ```
   /mapart status
   ```
8. Dung qua trinh dang chay:
   ```
   /mapart stop
   ```

## Build tu source

### Cach 1: GitHub Actions (khuyen nghi)
1. Push toan bo project nay len 1 repo GitHub.
2. Vao tab **Actions**, workflow "Build MapArt Mod" se tu chay.
3. Sau khi build xong (khoang 3-5 phut), vao run vua chay, phan
   **Artifacts** o cuoi trang, tai file `mapart-builder-mod` (.zip chua .jar).
4. Giai nen, lay file `.jar` (khong lay file co duoi `-sources.jar`),
   bo vao thu muc `mods/` cua Fabric.

### Cach 2: Build local
Can Java 21 (JDK) cai san.

```bash
./gradlew build
```

File jar nam trong `build/libs/mapart-builder-<version>.jar`.

## Yeu cau
- Minecraft 1.21.11
- Fabric Loader >= 0.18.0
- Fabric API (ban tuong ung 1.21.11)
- Java 21+

## Luu y
- Mod hoan toan client-side, khong can cai server-side.
- Lan dau khoi dong se mat vai giay de quet toan bo block texture va
  xay bang mau (ket qua duoc cache lai trong `mapart_data/mapart_palette_cache.json`,
  lan sau khoi dong nhanh hon nhieu).
- Nen dung o the gioi Creative/Singleplayer de test truoc khi dung Survival.
