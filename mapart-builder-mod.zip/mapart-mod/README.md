# MapArt Auto Builder

Mod Fabric (client-only) cho Minecraft 1.21.11: tu dong chuyen anh thanh
map art top-down (nhin tu tren xuong) va tu xay bang nhan vat that
(di chuyen + dat block giong nguoi choi, khong teleport, khong spam packet).

## Cach hoat dong

1. Bo anh (.png/.jpg/...) vao thu muc `mapart_input/` trong thu muc game
   (`.minecraft/mapart_input/`). Mod se tu tao thu muc nay neu chua co.
2. Vao game, mod se bao trong chat khi phat hien anh moi.
3. Go lenh:
   ```
   /mapart build <ten_file_anh> <rong> <cao>
   ```
   Vi du: `/mapart build house.png 64 64`
4. Mod KHONG tu san phang/pha block. No chi quet khu vuc (tai vi tri dang
   dung), ve vien bang glass de danh dau ranh gioi va bao so vi tri co vat
   can/ho trong. Ban tu don cay/vat can, lap ho (nen phai phang + dac) roi go:
   ```
   /mapart confirm
   ```
5. Mod bat dau tu dong xay: di chuyen + dat block theo tung hang.
   - Che do Creative: tu dong lay block can dung.
   - Che do Survival: kiem tra inventory, neu thieu se dung lai va bao
     chinh xac ten + so luong item con thieu trong chat.
6. Neu bi dung lai (thieu item, thoat game, crash...), bo sung item roi go:
   ```
   /mapart resume
   ```
7. Xem tien do bat cu luc nao:
   ```
   /mapart status
   ```
8. Dung qua trinh dang chay:
   ```
   /mapart stop
   ```
9. **Xem truoc toan bo danh sach block/item can co** de xay xong toan bo
   anh. Nen dung ngay sau khi convert anh (buoc 4), TRUOC khi confirm, de
   chuan bi du item 1 lan thay vi phai dung lai giua chung nhieu lan:
   ```
   /mapart list
   ```
   In ra ten block, ma dinh danh, so o can dung va so stack tuong ung
   (lam tron len), sap xep giam dan theo so luong.

## Build tu source

### Cach 1: GitHub Actions (khuyen nghi)
1. Push toan bo project nay len 1 repo GitHub.
2. Vao tab **Actions**, workflow "Build MapArt Mod" se tu chay.
3. Sau khi build xong (khoang 3-5 phut), vao run vua chay, phan
   **Artifacts** o cuoi trang, tai file `mapart-builder-mod` (.zip chua .jar).
4. Giai nen, lay file `.jar` (khong lay file co duoi `-sources.jar`),
   bo vao thu muc `mods/` cua Fabric.

### Cach 2: Build local
Can Java 21 (JDK) cai san.

```bash
./gradlew build
```

File jar nam trong `build/libs/mapart-builder-<version>.jar`.

## Yeu cau
- Minecraft 1.21.11
- Fabric Loader >= 0.18.0
- Fabric API (ban tuong ung 1.21.11)
- Java 21+

## Luu y
- Mod hoan toan client-side, khong can cai server-side.
- Lan dau khoi dong se mat vai giay de quet toan bo block texture va
  xay bang mau (ket qua duoc cache lai trong `mapart_data/mapart_palette_cache.json`,
  lan sau khoi dong nhanh hon nhieu).
- Nen dung o the gioi Creative/Singleplayer de test truoc khi dung Survival.
- Nen xay phai la mat phang, dac (block dat len tren y = vi tri dung - 1). O nao
  khong dat duoc se bi bo qua va bao lai o cuoi luot xay.
- Phim tat **M** mo GUI danh sach block (co thanh tien do realtime va nut
  Stop/Resume). Doi phim trong Options > Controls.


## Cap nhat: sua mau / chon block (v2)

**Loi da sua**: bang mau doc texture bi dao kenh R<->B (1.21.11 `getColorArgb` tra ARGB chuan),
nen xanh cyan/navy bi ra vang/nau. Cache doi ten thanh `mapart_palette_cache_v2.json` de bo cache cu.

**Cai tien chuyen anh -> block**
- Khoang cach mau dung CIELAB (chinh xac hon RGB/redmean voi xanh, tim).
- Loai block texture lon xon (ore, gravel...) bang do lech chuan mau + blacklist mo rong.
- Nen trang o RIA anh (flood fill tu mep) khong dat block; trang giua anh van giu.
- Resize nhieu buoc + lam sach pixel le o vien (bo nhieu anti-alias).
- (v4: USE_DITHERING / USE_KMEANS da bo, thay bang thuat toan 2 tang, xem muc v4 ben duoi.)

**Tu chon block**: sua `mapart_data/block_config.json` (tu tao lan chay dau), roi restart game:
```json
{
  "only": ["lapis_block", "diamond_block", "light_blue_wool", "black_concrete"],
  "exclude": ["blue_terracotta"],
  "excludeKeywords": ["terracotta"],
  "overrides": { "blue_wool": [20, 40, 110] }
}
```
`only` khong rong => chi dung dung cac block do (huu ich khi chi co san vai loai trong inventory).
Ten block viet khong co `minecraft:`. Doi config khong can xoa cache.

## Cap nhat v4: sprint + loai snow/powder_snow

**Sprint khi xay**: nhan vat tu dong sprint (~5.6 block/giay) thay vi di bo (~4.3 b/s) khi con
xa > 1 block, tu tat sprint khi dang vao window de dat block. Luoi 100x100 giam tu ~40 phut
xuong ~30 phut. Nhan vat tu dung su dung nuoc/deo to, neu muon nhanh hon nua thi dung Creative.

**Loai snow va powder_snow**: `snow` (snow layer - tu sinh ra o biome tuyet, khong phai solid block)
va `powder_snow` (item la bucket, khong dat duoc bang right-click binh thuong) da bi loai khoi
palette. Cache doi ten thanh `mapart_palette_cache_v3.json` de tu dong rebuild.

## Cap nhat v3: het "ran ri" o vung mau muot (toc, da...)

- `ImageConverter.USE_KMEANS` (mac dinh **true**, `KMEANS_K = 16`): gom mau anh thanh K cum roi moi cum -> 1 block,
  co median 3x3 (khu nhieu JPEG) va loc mode 3x3 (xoa o le). Seed co dinh nen `/mapart resume` ra dung luoi cu.
  Hop voi anime / logo. Anh chup nhieu sac do: dat `USE_KMEANS=false` (va co the bat `USE_DITHERING`).
- `BlockColorEntry.W_L / W_C` (mac dinh 0.4 / 3.5): trong so do sang / sac do. `W_C` cao => giu dung tong mau
  (toc nau khong bi ra xam), doi lai mau trang co the ngả kem. Muon trang tinh hon thi giam `W_C` (vd 2.0).
- Muon nhieu chi tiet hon: tang `KMEANS_K` (20-24) hoac tang kich thuoc anh (width/height).

## Cap nhat v4: vua CHI TIET vua DUNG MAU (thuat toan 2 tang)

`ImageConverter` viet lai hoan toan, deterministic (khong Random) nen `/mapart resume` van ra dung luoi cu.

- **Palette con bang greedy** (`PALETTE_K`, mac dinh 28): moi buoc them block lam giam sai so nhieu nhat, nen block
  hiem nhung quan trong (nau-tro cua toc, hong cua mat, do cua ao) van duoc chon, khong bi block pho bien nuot mat.
- **Canh/chi tiet** (net vien, mieng, sao trong mat, hoa tren mu, highlight): phat hien bang Sobel tren do sang + mau,
  o canh lay **pixel goc** map thang -> giu net 1 block.
- **Vung phang**: chia manh (SLIC don gian), moi manh 1 block. Rieng vung TOI ma mau nam giua 2 block
  (vd toc nau-tro giua xam va hong) thi tron 2 block bang Bayer 4x4 -> ra dung tong mau nau, doi lai hoi "ro"
  (dung y "chap nhan hoi ro/dither o toc"). Vung SANG (da, ma) giu 1 block dac cho sach.
- Loc mode 3x3 chi o vung phang (khong dong vao canh / vung dang dither).

Tinh chinh (deu la `public static` trong `ImageConverter`):
- `PALETTE_K` 28: tang (32-40) => them sac thai nhung phai chuan bi nhieu loai block hon.
- `W_L / W_C` 1.0 / 1.6: `W_C` cao => giu hue (toc nau khong ra xam) nhung da co the ngả kem.
- `EDGE_L_THRESHOLD / EDGE_C_THRESHOLD` 7 / 9: giam => nhieu o duoc coi la chi tiet (net hon, it muot hon).
- `USE_BAYER_BLEND` true: tat de vung phang sach hoan toan (nhung mat tong mau nau cua toc).
- `SEGMENT_AREA` 60: dien tich manh; nho hon => chi tiet hon.
- Luu y: `BlockColorEntry.W_L / W_C` cu khong con dung trong convert nua (chi con `distanceTo`, khong ai goi).

### v4.1 (chon CAP tron dung mau, dua tren palette that)
- Truoc day vung phang tron "2 block GAN NHAT" -> palette that (208 block) khong co block nau-tro nen toc ra xam + hong sai tong.
  Nay chon **cap block cho ra mau tron dung nhat** (residual nho nhat): vd toc nau-tro = `stone_bricks` + `purple_terracotta` (~62/38).
- Chi tron Bayer khi vung **du sang va du co hue**: vung qua toi (mu den, L*<35) giu 1 block cho sach.
- Tham so moi (public static trong `ImageConverter`): `BLEND_MIN_LIGHTNESS` 35, `BLEND_MIN_CHROMA` 8, `BLEND_MAX_PAIR` 40, `BLEND_MAX_RESIDUAL` 5.
- Kem file `mapart_simulator.html`: mo bang trinh duyet (dien thoai cung duoc), da nhung san palette that; co the nap lai
  `mapart_palette_cache_v3.json` / `block_config.json` / anh khac. Hien ban MOI va ban CU canh nhau, nhin tu tren xuong,
  kem danh sach block can chuan bi. Cac thanh truot tuong ung 1-1 voi cac tham so o tren.

### v4.2 (fix: qua roi khi mo palette)

Bro test v4.1 voi palette rong (`v4`, tat loc stddev) thi anh bi roi - ly do va cach fix:

1. **`structure_block` lot vao palette** (thieu trong blacklist tu dau) + mot loat block "in hoa van/noi khoi"
   (`glazed_terracotta`, `chiseled_*`, `cracked_stone_bricks`, `cobblestone`, `raw_*_block`, `honeycomb_block`,
   `amethyst_block`, `sea_pickle`, `redstone_lamp`, `gilded_blackstone`, `quartz_pillar`, `*_coral_block`):
   mau trung binh dung nhung nhin tu tren xuong rat roi mat. Da them vao `BLACKLIST_KEYWORDS`.
2. **`MAX_TEXTURE_STDDEV`**: dat lai **45** (giua muc 28 cu qua chat va 999 luc do palette). Rong hon 28 de them
   duoc mau (go/da/terracotta van nhe), nhung khong tat han vi cac block qua "lon xon" da bi chan rieng o buoc 1.
3. **`BLEND_MAX_PAIR`**: giam tu 40 xuong **16**. 40 cho phep tron 2 block cach xa nhau (vd log nau + terracotta tim),
   ve so hoc dung mau trung binh nhung nhin caro rat gat. 16 vua giam nhieu (22% -> 10% cap o ke nhau khac block o
   vung mau muot) vua giam ca sai so mau (dE 8.18 -> 7.69) vi ep thuat toan chon cap gan mau hon that su.
4. **`EDGE_L_THRESHOLD` / `EDGE_C_THRESHOLD`**: nang tu 7/9 len **9/12**. Nguong thap qua khien vung chuyen mau
   muot trong toc bi coi la "canh", chay nearest tung pixel -> ra hat li ti giong nhieu JPEG cua anh nguon.
5. Cache doi ten thanh `mapart_palette_cache_v5.json` (danh sach block thay doi so voi `v4` Bro da gui).

Ket qua do tren anh Hu Tao (128x128, palette that sau loc con 184/237 block): sai so mau TB **7.77** (ban cu k-means
la 10.84), khong con hien tuong caro roi nhu ban `v4.1` truoc do.

Neu van thay chi tiet nhieu qua sau khi build, chinh theo thu tu re nhat truoc:
- `BLEND_MAX_PAIR` giam them (vd 12) => vung phang phang hon nua.
- `EDGE_L_THRESHOLD` / `EDGE_C_THRESHOLD` nang them (vd 11/14) => it pixel bi coi la "chi tiet" hon.
- `SEGMENT_AREA` tang (vd 90-120) => manh to hon, it manh vun.
- Nguoc lai, neu thay QUA muot/mat chi tiet, giam ca 3 tham so tren theo huong nguoc lai.

